#!/usr/bin/env bash
# Arcanum CE - native Linux setup (release 1, R7).
#
# Builds a game folder from the two Windows installers, with native tools and
# no Wine: GOG's offline installer for Arcanum 1.0.7.4 (unpacked by
# innoextract) and the Unofficial Arcanum Patch, UAP2.0.2.exe (unpacked by
# 7z). It lays down UAP's reference component set and the High Resolution
# Patch's files exactly as UAP's own installer and the patch's install script
# would, then installs Arcanum CE beside them with the release configuration.
#
#   ./setup.sh --gog setup_arcanum_*.exe --uap UAP2.0.2.exe [--dir DIR]
#              [--all-mods | --mod ID ...] [--no-desktop] [--yes]
#
# Setup asks about each optional mod in turn (release/mods.txt's questions),
# every answer defaulting to no. --all-mods or --mod ID (repeatable) answer in
# advance; with --yes and neither, all stay off. A mod can be turned on or off
# later with its line in arcanum-ce.cfg.
#
# DIR defaults to ~/Games/arcanum-ce and must be new or empty. Nothing outside
# DIR is written except the menu entry (~/.local/share/applications), which
# --no-desktop skips. uninstall.sh, copied into DIR, removes what this added.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GOG=""
UAP=""
DEST="${HOME}/Games/arcanum-ce"
DESKTOP=1
ASSUME_YES=0
ALL_MODS=0
WANTED_MODS=""

usage() { sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'; }
die() { printf 'setup: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

while [ $# -gt 0 ]; do
    case "$1" in
        --gog) GOG="$2"; shift 2 ;;
        --uap) UAP="$2"; shift 2 ;;
        --dir) DEST="$2"; shift 2 ;;
        --no-desktop) DESKTOP=0; shift ;;
        --all-mods) ALL_MODS=1; shift ;;
        --mod) WANTED_MODS="$WANTED_MODS $2"; shift 2 ;;
        --yes|-y) ASSUME_YES=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown argument: $1 (see --help)" ;;
    esac
done

# --- what is needed ---------------------------------------------------------

[ -n "$UAP" ] || die "--uap UAP2.0.2.exe is required"
[ -f "$UAP" ] || die "no such file: $UAP"
# A test hook, not a supported route: an already-unpacked GOG folder in place
# of the installer, for building the package where no installer is at hand.
GOG_DIR="${ARCANUM_SETUP_GOG_DIR:-}"
if [ -z "$GOG_DIR" ]; then
    [ -n "$GOG" ] || die "--gog setup_arcanum_*.exe is required (GOG's offline installer)"
    [ -f "$GOG" ] || die "no such file: $GOG"
fi
for f in arcanum-ce arcanum-ce.base.cfg mods.txt uap-2.0.2-reference.sha256 gog-1.0.7.4.sha256 uninstall.sh; do
    [ -e "$HERE/$f" ] || die "the package is incomplete: $f is missing beside setup.sh"
done

case "$DEST" in /*) ;; *) DEST="$PWD/$DEST" ;; esac
if [ -e "$DEST" ] && [ -n "$(ls -A "$DEST" 2>/dev/null)" ]; then
    die "$DEST already has files in it; choose a new folder with --dir"
fi

missing=""
if [ -z "$GOG_DIR" ]; then command -v innoextract >/dev/null || missing="$missing innoextract"; fi
command -v 7z >/dev/null || missing="$missing 7z"
command -v sha256sum >/dev/null || missing="$missing sha256sum"
if [ -n "$missing" ]; then
    say "setup needs:$missing"
    say "  Debian/Ubuntu: sudo apt install innoextract p7zip-full"
    say "  Fedora:        sudo dnf install innoextract p7zip p7zip-plugins"
    say "  Arch:          sudo pacman -S innoextract 7zip"
    exit 1
fi


say "Arcanum CE setup"
say "  GOG installer: ${GOG_DIR:-$GOG}"
say "  UAP installer: $UAP"
say "  game folder:   $DEST"
if [ "$ASSUME_YES" -eq 0 ]; then
    printf 'Continue? [y/N] '
    read -r answer
    case "$answer" in y|Y|yes|YES) ;; *) say "Nothing was changed."; exit 1 ;; esac
fi

# --- the optional mods: asked now, applied with the settings in step 4 -------

MOD_IDS=""
MOD_NAME=(); MOD_ABOUT=(); MOD_ID=(); MOD_QUESTION=()
while IFS=$'\t' read -r id name about question; do
    case "$id" in ''|\#*) continue ;; esac
    MOD_ID+=("$id"); MOD_NAME+=("$name"); MOD_ABOUT+=("$about"); MOD_QUESTION+=("$question")
    MOD_IDS="$MOD_IDS $id"
done < "$HERE/mods.txt"
for id in $WANTED_MODS; do
    case " $MOD_IDS " in *" $id "*) ;; *) die "no optional mod called $id (there are:$MOD_IDS)" ;; esac
done
ask() {  # ask QUESTION -> 0 for yes; no is the default
    local answer
    printf '%s [y/N] ' "$1"
    read -r answer || answer=""
    case "$answer" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}
ON_MODS=""
if [ "$ALL_MODS" -eq 1 ]; then
    ON_MODS="$MOD_IDS"
elif [ -n "$WANTED_MODS" ]; then
    ON_MODS="$WANTED_MODS"
elif [ "$ASSUME_YES" -eq 0 ]; then
    say ""
    say "Arcanum CE comes with ${#MOD_ID[@]} optional mods, each off unless you turn it on:"
    for i in "${!MOD_ID[@]}"; do
        say ""
        say "  ${MOD_NAME[i]}: ${MOD_ABOUT[i]}."
        if ask "${MOD_QUESTION[i]}"; then ON_MODS="$ON_MODS ${MOD_ID[i]}"; fi
    done
fi

mkdir -p "$DEST"
WORK="$DEST/.setup-work"
mkdir -p "$WORK"
trap 'rm -rf "$WORK"' EXIT

# --- placing files without regard to case -------------------------------------
#
# Windows merges `Modules` and `modules`; Linux would keep both, and the
# engine would see whichever it resolved first. Every placement below follows
# an existing spelling of each path component, whatever its case.

match_child() {  # match_child DIR NAME -> the existing entry spelt NAME in any case
    local dir="$1" name="$2" entry
    for entry in "$dir"/* "$dir"/.[!.]*; do
        [ -e "$entry" ] || continue
        if [ "${entry##*/}" = "$name" ] || [ "$(printf '%s' "${entry##*/}" | tr 'A-Z' 'a-z')" = "$(printf '%s' "$name" | tr 'A-Z' 'a-z')" ]; then
            printf '%s' "$entry"
            return 0
        fi
    done
    return 1
}

resolve() {  # resolve REL -> a path under DEST, creating directories as needed
    local rel="$1" path="$DEST" found i last
    local -a parts
    IFS='/' read -r -a parts <<< "$rel"
    last=$(( ${#parts[@]} - 1 ))
    for (( i = 0; i < last; i++ )); do
        if found="$(match_child "$path" "${parts[i]}")"; then path="$found"
        else path="$path/${parts[i]}"; mkdir -p "$path"; fi
    done
    if found="$(match_child "$path" "${parts[last]}")"; then printf '%s' "$found"
    else printf '%s' "$path/${parts[last]}"; fi
}

place() {  # place SRC REL: copy one file into DEST at REL, case-merged
    local target
    target="$(resolve "$2")"
    cp -f "$1" "$target"
}

place_tree() {  # place_tree SRC_DIR REL_DIR: every file under SRC_DIR
    local src="$1" rel="$2" file
    while IFS= read -r -d '' file; do
        place "$file" "$rel/${file#"$src"/}"
    done < <(find "$src" -type f -print0)
}

# --- 1. the base game, from GOG's installer ------------------------------------

say "1/5 unpacking the base game..."
if [ -n "$GOG_DIR" ]; then
    GOG_ROOT="$GOG_DIR"
else
    innoextract --silent --progress=0 --exclude-temp -d "$WORK/gog" "$GOG" \
        || die "innoextract could not unpack $GOG"
    tig="$(find "$WORK/gog" -maxdepth 3 -iname tig.dat -type f | head -1)"
    [ -n "$tig" ] || die "$GOG does not look like Arcanum's GOG installer (no tig.dat inside)"
    GOG_ROOT="$(dirname "$tig")"
fi
cp -a "$GOG_ROOT"/. "$DEST"/
# GOG's own installer machinery, not the game. Measured on GOG's 1.0.7.4
# "ddrawfix" build (77721), whose game files sit at the top: `__redist`,
# `commonappdata` and an `app` folder holding only an icon and a web cache.
rm -rf "$DEST/__redist" "$DEST/__support" "$DEST/commonappdata" "$DEST/tmp" 2>/dev/null || true
if [ -d "$DEST/app" ] && [ -z "$(find "$DEST/app" -iname tig.dat | head -1)" ]; then
    rm -rf "$DEST/app"
fi

gog_mismatch=0
while read -r sum rel; do
    case "$sum" in ''|\#*) continue ;; esac
    file="$(resolve "$rel")"
    if [ ! -f "$file" ]; then
        die "the base game is missing $rel - is this Arcanum's GOG installer?"
    fi
    if [ "$(sha256sum < "$file" | cut -d' ' -f1)" != "$sum" ]; then
        gog_mismatch=1
        say "  note: $rel differs from GOG 1.0.7.4 as this release was tested with"
    fi
done < "$HERE/gog-1.0.7.4.sha256"
[ "$gog_mismatch" -eq 0 ] && say "  GOG Arcanum 1.0.7.4 found"

# --- 2. UAP's reference component set ------------------------------------------

say "2/5 unpacking the Unofficial Arcanum Patch..."
7z x -y -bd -o"$WORK/uap" "$UAP" > "$WORK/7z.log" 2>&1 \
    || die "7z could not unpack $UAP (see the 7z output above)"
while read -r sum rel; do
    case "$sum" in ''|\#*) continue ;; esac
    src="$WORK/uap/$rel"
    [ -f "$src" ] || die "$UAP has no $rel - this release needs UAP 2.0.2"
    if [ "$(sha256sum < "$src" | cut -d' ' -f1)" != "$sum" ]; then
        die "$rel inside $UAP is not UAP 2.0.2's - this release needs UAP 2.0.2"
    fi
    place "$src" "$rel"
done < "$HERE/uap-2.0.2-reference.sha256"
# UAP's installer runs Sierra's RemoveProtos.exe: loose prototypes left by an
# earlier version hide the archives' (now UAP's) copies. A fresh folder has
# none; step 5's check reports any that appear.
say "  UAP 2.0.2: data, animations, ambient sounds, races, Pyro Bow, Virgil fix, no movies, no noise"

# --- 3. the High Resolution Patch, as HighRes.tp2 installs it ----------------

say "3/5 the High Resolution Patch..."
HRP="$WORK/uap/HighRes/Files"
CONFIG="$(resolve HighRes/config.ini)"
[ -f "$CONFIG" ] || die "UAP's HighRes/config.ini was not laid down"
setting() {  # setting KEY -> its integer value in HighRes/config.ini
    tr -d '\r' < "$CONFIG" | sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*\([0-9]*\).*/\1/p" | head -1
}
WIDTH="$(setting Width)"; BORDERS="$(setting Borders)"; MENU_ART="$(setting MainMenuArt)"
[ -n "$WIDTH" ] || die "HighRes/config.ini has no Width"

# _install.bat clears the modules' map folders (their top-level files) first.
for module in Arcanum Vormantown; do
    maps="$(resolve "modules/$module/maps/.keep")"; maps="${maps%/.keep}"
    find "$maps" -maxdepth 1 -type f -delete
done
# Sound positioning scaled to the screen width.
sound="$(resolve data/sound/soundparams.mes)"
sed -e "s/{1}{50}/{1}{$((WIDTH / 16))}/" -e "s/{2}{800}/{2}{$WIDTH}/" \
    -e "s/{3}{100}/{3}{$((WIDTH / 8))}/" -e "s/{4}{400}/{4}{$((WIDTH / 2))}/" \
    "$HRP/soundparams.mes" > "$sound"
# The shop map (the main menu's backdrop) and the half-ogre captain fix.
place_tree "$HRP/maps/ShopMap" modules/Arcanum/maps/ShopMap
place_tree "$HRP/maps/ShopMap" modules/Vormantown/maps/ShopMap
place_tree "$HRP/maps/Arcanum1-024-fixed" modules/Arcanum/maps/Arcanum1-024-fixed
if [ "${MENU_ART:-0}" = 2 ]; then
    place "$HRP/maps/0_dirt.sec" modules/Arcanum/maps/ShopMap/0.sec
    place "$HRP/maps/0_dirt.sec" modules/Vormantown/maps/ShopMap/0.sec
fi
place "$HRP/ArcanumZHighRes.dat" ArcanumZHighRes.dat
if [ "${BORDERS:-0}" = 1 ]; then
    place "$HRP/ArcanumZHighResBorders.dat" ArcanumZHighResBorders.dat
fi
# The patch's exe changes and its ddraw.dll are the original's; CE implements
# the patch's settings itself and reads HighRes/config.ini.
say "  ${WIDTH}x$(setting Height), borders ${BORDERS:-0}, menu art ${MENU_ART:-0} (HighRes/config.ini)"

# --- 4. Arcanum CE --------------------------------------------------------------

say "4/5 installing Arcanum CE..."
MANIFEST="$DEST/.arcanum-ce-install"
: > "$MANIFEST"
own() { printf '%s\n' "$1" >> "$MANIFEST"; }
install -m 0755 "$HERE/arcanum-ce" "$DEST/arcanum-ce"; own arcanum-ce
install -m 0755 "$HERE/uninstall.sh" "$DEST/arcanum-ce-uninstall.sh"; own arcanum-ce-uninstall.sh
for doc in README.md LICENSE.md THIRD-PARTY-NOTICES.md CHANGES.md; do
    if [ -f "$HERE/$doc" ]; then
        install -m 0644 "$HERE/$doc" "$DEST/arcanum-ce-$doc"; own "arcanum-ce-$doc"
    fi
done
if [ -d "$HERE/ce-mods" ]; then
    cp -a "$HERE/ce-mods" "$DEST/ce-mods"; own ce-mods
fi
# CE's own settings: the original's arcanum.cfg (if the game came with one)
# with the release's lines laid over it. The original's file is never touched.
cfg="$DEST/arcanum-ce.cfg"
if [ -f "$DEST/arcanum.cfg" ]; then cp "$DEST/arcanum.cfg" "$cfg"; else : > "$cfg"; fi
while IFS= read -r line; do
    case "$line" in ''|\#*) continue ;; esac
    key="${line%%=*}"
    if grep -q "^${key}=" "$cfg"; then
        tmp="$cfg.tmp"
        awk -v k="$key" -v l="$line" 'index($0, k "=") == 1 { print l; next } { print }' "$cfg" > "$tmp"
        mv "$tmp" "$cfg"
    else
        printf '%s\n' "$line" >> "$cfg"
    fi
done < "$HERE/arcanum-ce.base.cfg"
for id in $ON_MODS; do
    tmp="$cfg.tmp"
    awk -v k="mod $id=" -v l="mod $id=1" 'index($0, k) == 1 { print l; next } { print }' "$cfg" > "$tmp"
    mv "$tmp" "$cfg"
done
own arcanum-ce.cfg

# --- 5. check, and a menu entry ---------------------------------------------------

say "5/5 checking the installation..."
set +e
( cd "$DEST" && ./arcanum-ce -check-install ) > "$WORK/check.log" 2>&1
check=$?
set -e
sed 's/^/  /' "$WORK/check.log"
if [ "$check" -eq 1 ]; then
    say "  Moving the loose prototypes that hide UAP's fixes aside:"
    ( cd "$DEST" && ./arcanum-ce -check-install-fix ) | tail -2 | sed 's/^/  /'
elif [ "$check" -ne 0 ]; then
    die "the installation check failed (exit $check); see above"
fi

if [ "$DESKTOP" -eq 1 ]; then
    apps="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
    mkdir -p "$apps"
    icon="$(resolve goggame-1207658829.ico)"
    {
        echo "[Desktop Entry]"
        echo "Type=Application"
        echo "Name=Arcanum CE"
        echo "Comment=Arcanum: Of Steamworks and Magick Obscura - Community Edition"
        echo "Exec=\"$DEST/arcanum-ce\""
        echo "Path=$DEST"
        [ -f "$icon" ] && echo "Icon=$icon"
        echo "Terminal=false"
        echo "Categories=Game;RolePlaying;"
    } > "$apps/arcanum-ce.desktop"
    own "desktop:$apps/arcanum-ce.desktop"
    say "  menu entry: $apps/arcanum-ce.desktop"
fi

say ""
say "Done. Start the game from the menu, or:"
say "  cd \"$DEST\" && ./arcanum-ce"
say "Saves go to $DEST/modules/Arcanum/SaveCE. Settings: $DEST/arcanum-ce.cfg."
if [ -n "$ON_MODS" ]; then say "Optional mods on:$ON_MODS"; else say "Optional mods: all off (each is a line in arcanum-ce.cfg)."; fi
say "To remove Arcanum CE: \"$DEST/arcanum-ce-uninstall.sh\""
