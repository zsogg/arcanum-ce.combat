#!/usr/bin/env bash
# Arcanum CE - remove what setup.sh installed (release 1, R7).
#
#   ./arcanum-ce-uninstall.sh [--all] [--yes]
#
# Without --all it removes Arcanum CE itself - the program, its settings,
# the optional mods and the menu entry - and leaves the game files and the
# saves (modules/Arcanum/SaveCE). With --all it deletes the whole game folder
# setup.sh made, saves included, after asking.
set -euo pipefail

DEST="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ALL=0
ASSUME_YES=0
while [ $# -gt 0 ]; do
    case "$1" in
        --all) ALL=1; shift ;;
        --yes|-y) ASSUME_YES=1; shift ;;
        -h|--help) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "uninstall: unknown argument: $1" >&2; exit 1 ;;
    esac
done

MANIFEST="$DEST/.arcanum-ce-install"
[ -f "$MANIFEST" ] || { echo "uninstall: $DEST was not set up by Arcanum CE's setup.sh" >&2; exit 1; }

confirm() {
    [ "$ASSUME_YES" -eq 1 ] && return 0
    printf '%s [y/N] ' "$1"
    read -r answer
    case "$answer" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

if [ "$ALL" -eq 1 ]; then
    saves="$DEST/modules/Arcanum/SaveCE"
    if [ -d "$saves" ] && [ -n "$(ls -A "$saves" 2>/dev/null)" ]; then
        echo "This deletes your Arcanum CE saves in $saves too."
    fi
    confirm "Delete the whole folder $DEST?" || { echo "Nothing was removed."; exit 1; }
fi

while IFS= read -r entry; do
    case "$entry" in
        desktop:*) rm -f "${entry#desktop:}" ;;
        ''|*/..*|..*|/*) ;;   # never outside the folder
        *) rm -rf "${DEST:?}/$entry" ;;
    esac
done < "$MANIFEST"
rm -f "$MANIFEST"
rm -f "$DEST/arcanum-ce.log"   # written by the game, not setup; not a save

if [ "$ALL" -eq 1 ]; then
    rm -rf "${DEST:?}"
    echo "Removed $DEST."
else
    echo "Arcanum CE removed. The game files and your saves remain in $DEST."
fi
