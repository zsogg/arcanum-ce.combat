@echo off
rem Arcanum CE setup: runs setup.ps1 with Windows PowerShell, whatever the execution policy.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
