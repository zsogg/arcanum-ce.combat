# Arcanum CE - remove what setup.ps1 installed (release 1, R8).
#
# Removes Arcanum CE's files from the game folder and any shortcut setup made.
# The game, the original Arcanum.exe, its saves and CE's saves
# (modules\Arcanum\SaveCE) are left in place.
#
# Runs from the game folder (arcanum-ce-uninstall.bat, installed by setup) or
# from the unzipped package (uninstall.bat), which finds the game folder as
# setup does. Asks first, then says "Uninstall in progress...", then
# "Uninstall complete.", then waits for Enter (zsogg, 2026-10-17). -Yes skips
# the question and the wait. -FromBatch is the .bat's: the .bat waits for
# Enter itself, so the window stays open even if PowerShell fails.
#
#   arcanum-ce-uninstall.bat [-GameDir DIR] [-Yes]
[CmdletBinding()]
param(
    [string]$GameDir = "",
    [switch]$Yes,
    [switch]$FromBatch
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestName = ".arcanum-ce-install"

# The window a double-click opens closes when the script ends: every way out
# waits for Enter first, so the last message can be read.
function Finish([int]$Code) {
    if (-not $Yes -and -not $FromBatch) { Read-Host "Press Enter to exit the uninstaller" | Out-Null }
    exit $Code
}

# --- the game folder (as setup.ps1 finds it) ----------------------------------

function Test-GameDir([string]$Dir) {
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    # Join-Path throws on a drive that does not exist (a registry entry left
    # pointing at a removed drive): that is simply not the game folder.
    try {
        return (Test-Path -LiteralPath (Join-Path $Dir "tig.dat")) -and
               (Test-Path -LiteralPath (Join-Path $Dir "Arcanum.exe"))
    } catch { return $false }
}

function Find-GameDir {
    $candidates = New-Object System.Collections.Generic.List[string]
    $keys = @(
        @("HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\Sierra OnLine\Setup\AR_USENG", "Directory")
    )
    foreach ($key in $keys) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key[0] -ErrorAction Stop).($key[1])
            if ($value) { $candidates.Add($value.TrimEnd('\')) }
        } catch { }
    }
    foreach ($dir in @("C:\GOG Games\Arcanum", "C:\GOG Games\Arcanum - Of Steamworks and Magick Obscura",
                       "C:\Program Files (x86)\GOG Galaxy\Games\Arcanum",
                       "C:\Program Files (x86)\GOG.com\Arcanum")) {
        $candidates.Add($dir)
    }
    foreach ($dir in $candidates) {
        if (Test-GameDir $dir) { return $dir }
    }
    return ""
}

# --- end of what setup.ps1 shares ---------------------------------------------

Write-Host "Arcanum CE uninstall"
# Run from the game folder itself (the installed copy), rather than the package.
$InGameDir = Test-Path -LiteralPath (Join-Path $Here $ManifestName)
if (-not $GameDir) {
    if ($InGameDir) {
        $GameDir = $Here
    } else {
        $found = Find-GameDir
        if ($found -and (Test-Path -LiteralPath (Join-Path $found $ManifestName))) {
            $GameDir = $found
        } elseif (-not $Yes) {
            $GameDir = [string](Read-Host "Arcanum CE was not found. The folder it is installed in")
        }
    }
}
$GameDir = ([string]$GameDir).Trim().Trim('"').TrimEnd('\')
$Manifest = $(if ($GameDir) { Join-Path $GameDir $ManifestName } else { "" })
if (-not $Manifest -or -not (Test-Path -LiteralPath $Manifest)) {
    Write-Host "Arcanum CE is not installed in '$GameDir' (it was not set up by Arcanum CE's setup). Nothing was removed." -ForegroundColor Red
    Finish 1
}
Write-Host "  Arcanum CE is installed in $GameDir"
if (-not $Yes) {
    $answer = ""
    while ($answer -notmatch '^(y|yes|n|no)$') {
        $answer = "$(Read-Host "Do you want to uninstall Arcanum CE? Your saves stay. [y/n]")".Trim().ToLower()
    }
    if ($answer -match '^(n|no)$') {
        Write-Host "Nothing was removed."
        Finish 1
    }
}

Write-Host "Uninstall in progress..."
$self = @("arcanum-ce-uninstall.ps1", "arcanum-ce-uninstall.bat")
try {
    foreach ($entry in Get-Content -LiteralPath $Manifest) {
        if (-not $entry) { continue }
        if ($entry.StartsWith("shortcut:")) {
            Remove-Item -LiteralPath $entry.Substring(9) -Force -ErrorAction SilentlyContinue
            continue
        }
        # Only names inside the game folder, never a path that climbs out of it.
        if ($entry.Contains("..") -or [System.IO.Path]::IsPathRooted($entry)) { continue }
        if ($self -contains $entry) { continue }
        $path = Join-Path $GameDir $entry
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    }
    Remove-Item -LiteralPath $Manifest -Force
    # Written by the game, not setup, so not in the record; it is not a save.
    Remove-Item -LiteralPath (Join-Path $GameDir "arcanum-ce.log") -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "The uninstall stopped: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Close Arcanum CE if it is running, then run the uninstaller again."
    Finish 1
}

# The scripts in the game folder go last, once nothing more is read from them.
# A running .bat cannot be deleted under itself: arcanum-ce-uninstall.bat
# removes itself once this script has returned.
Remove-Item -LiteralPath (Join-Path $GameDir "arcanum-ce-uninstall.ps1") -Force -ErrorAction SilentlyContinue
$bat = Join-Path $GameDir "arcanum-ce-uninstall.bat"
if (-not ($FromBatch -and $InGameDir)) {
    Remove-Item -LiteralPath $bat -Force -ErrorAction SilentlyContinue
}
Write-Host "Uninstall complete. Arcanum CE is removed; the game and your saves (modules\Arcanum\SaveCE) remain in $GameDir."
Finish 0
