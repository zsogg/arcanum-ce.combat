@echo off
rem Arcanum CE uninstall: runs the uninstall script with Windows PowerShell,
rem whatever the execution policy, and keeps this window open at the end -
rem also if PowerShell could not run the script at all.
rem Works from the game folder (arcanum-ce-uninstall.bat) and from the
rem unzipped package (uninstall.bat), which finds the game folder.
setlocal
set "POWERSHELL=powershell.exe"
if defined ARCANUM_SETUP_POWERSHELL set "POWERSHELL=%ARCANUM_SETUP_POWERSHELL%"
set "WAIT=1"
for %%A in (%*) do if /i "%%~A"=="-Yes" set "WAIT="
set "RC=1"
set "SCRIPT=%~dp0arcanum-ce-uninstall.ps1"
if not exist "%SCRIPT%" set "SCRIPT=%~dp0uninstall.ps1"
if exist "%SCRIPT%" goto run
echo The uninstall script is missing: arcanum-ce-uninstall.ps1 should be beside this file.
echo Nothing was removed.
goto done
:run
call "%POWERSHELL%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -FromBatch %*
set "RC=%errorlevel%"
if "%RC%"=="0" goto done
if "%RC%"=="1" goto done
echo.
echo Windows PowerShell could not run the uninstall script (exit code %RC%).
:done
if not defined WAIT goto finish
echo.
set /p "ANSWER=Press Enter to exit the uninstaller: "
:finish
rem The installed copy removes itself last, once Arcanum CE is gone: a batch
rem file cannot be deleted while it runs.
if /i not "%~nx0"=="arcanum-ce-uninstall.bat" exit /b %RC%
if exist "%~dp0.arcanum-ce-install" exit /b %RC%
(goto) 2>nul & del "%~f0"
