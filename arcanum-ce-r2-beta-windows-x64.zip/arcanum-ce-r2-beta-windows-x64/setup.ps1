# Arcanum CE - Windows setup (release 1, R8).
#
# Installs Arcanum CE into an existing Arcanum folder: GOG Arcanum 1.0.7.4 with
# the Unofficial Arcanum Patch 2.0.2 (and its High Resolution Patch) already
# installed the usual way. The original Arcanum.exe and its saves are left as
# they are; CE keeps its own saves (modules\Arcanum\SaveCE) and settings
# (arcanum-ce.cfg).
#
# Nothing outside the game folder is written - no registry value, no file in
# the user's profile or %TEMP% - unless the player asks for a shortcut:
# -StartMenuShortcut and -DesktopShortcut each add one .lnk, which the
# uninstaller removes. (Windows PowerShell keeps its own caches under
# %LOCALAPPDATA% whenever any script runs; that is PowerShell's, not this.)
#
#   setup.bat                          (double-click; finds the game folder)
#   setup.bat -GameDir "C:\GOG Games\Arcanum" [-AllMods | -Mod ID,...]
#             [-StartMenuShortcut] [-DesktopShortcut] [-Yes]
#
# Every run shows what each switch does and asks about each optional mod in
# turn (mods.txt's questions): on a first install every answer defaults to
# no, on an update to the mod's current setting. -AllMods or -Mod answer in
# advance; -Yes with neither keeps the settings as they are (all off on a
# first install).
#
# Written for Windows PowerShell 5.1, which every Windows 10 and 11 has.
[CmdletBinding()]
param(
    [string]$GameDir = "",
    [switch]$AllMods,
    [string[]]$Mod = @(),
    [switch]$StartMenuShortcut,
    [switch]$DesktopShortcut,
    [switch]$Yes
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestName = ".arcanum-ce-install"

function Say([string]$Text) { Write-Host $Text }
function Fail([string]$Text) {
    Write-Host ""
    Write-Host "setup: $Text" -ForegroundColor Red
    if (-not $Yes) { Read-Host "Press Enter to close" | Out-Null }
    exit 1
}
function Ask([string]$Question, [bool]$Default = $false) {
    if ($Yes) { return $true }
    $hint = $(if ($Default) { "[Y/n]" } else { "[y/N]" })
    while ($true) {
        # "$(...)" is a string even when Read-Host returns $null at the end of
        # redirected input; [string]$null stays $null (r2-test1, 2026-10-29).
        $answer = "$(Read-Host "$Question $hint")".Trim().ToLower()
        if ($answer -eq "") { return $Default }
        if ($answer -match '^(y|yes)$') { return $true }
        if ($answer -match '^(n|no)$') { return $false }
        Say "  Please answer y or n."
    }
}

# --- the package -------------------------------------------------------------

foreach ($name in @("arcanum-ce.exe", "arcanum-ce.base.cfg", "mods.txt", "setup-summary.txt", "uninstall.ps1", "uninstall.bat")) {
    if (-not (Test-Path -LiteralPath (Join-Path $Here $name))) {
        Fail "the package is incomplete: $name is missing beside setup.ps1"
    }
}

# --- the game folder ----------------------------------------------------------

function Test-GameDir([string]$Dir) {
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    # Join-Path throws on a drive that does not exist (a registry entry left
    # pointing at a removed drive): that is simply not the game folder.
    try {
        return (Test-Path -LiteralPath (Join-Path $Dir "tig.dat")) -and
               (Test-Path -LiteralPath (Join-Path $Dir "Arcanum.exe"))
    } catch { return $false }
}

function Find-GameDir {
    $candidates = New-Object System.Collections.Generic.List[string]
    $keys = @(
        @("HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\Sierra OnLine\Setup\AR_USENG", "Directory")
    )
    foreach ($key in $keys) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key[0] -ErrorAction Stop).($key[1])
            if ($value) { $candidates.Add($value.TrimEnd('\')) }
        } catch { }
    }
    foreach ($dir in @("C:\GOG Games\Arcanum", "C:\GOG Games\Arcanum - Of Steamworks and Magick Obscura",
                       "C:\Program Files (x86)\GOG Galaxy\Games\Arcanum",
                       "C:\Program Files (x86)\GOG.com\Arcanum")) {
        $candidates.Add($dir)
    }
    foreach ($dir in $candidates) {
        if (Test-GameDir $dir) { return $dir }
    }
    return ""
}

Say "Arcanum CE setup"
if (-not $GameDir) {
    $GameDir = Find-GameDir
    if ($GameDir) {
        Say "  found Arcanum in $GameDir"
        if (-not (Ask "Install Arcanum CE there?" $true)) {
            $GameDir = Read-Host "The folder Arcanum is installed in"
        }
    } elseif (-not $Yes) {
        $GameDir = Read-Host "Arcanum was not found. The folder it is installed in"
    }
}
$GameDir = $GameDir.Trim().Trim('"').TrimEnd('\')
if (-not (Test-GameDir $GameDir)) {
    Fail "'$GameDir' is not an Arcanum folder (no tig.dat and Arcanum.exe). Install GOG Arcanum first."
}

# GOG's own spellings; nested Join-Path rather than "\" so the script's logic
# can also be tested where paths are case-sensitive and "/"-separated.
foreach ($name in @("arcanum1.dat", "arcanum2.dat", "arcanum3.dat", "Arcanum4.dat", "modules/Arcanum.dat")) {
    $path = $GameDir
    foreach ($part in $name.Split("/")) { $path = Join-Path $path $part }
    if (-not (Test-Path -LiteralPath $path)) {
        Fail "the base game is incomplete: $name is missing in $GameDir"
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $GameDir "Arcanum5.dat"))) {
    Fail "the Unofficial Arcanum Patch is not installed in $GameDir (no Arcanum5.dat). Run UAP2.0.2.exe first."
}
if (-not (Test-Path -LiteralPath (Join-Path (Join-Path $GameDir "HighRes") "config.ini"))) {
    Say "  note: the High Resolution Patch is not installed; CE will use the original 800x600."
}

# CE is a 64-bit program, and Windows does not redirect a 64-bit program's
# writes out of Program Files as it does the original's - so a folder the
# player cannot write to cannot hold CE's saves and settings.
$probe = Join-Path $GameDir (".arcanum-ce-write-test-" + [Guid]::NewGuid().ToString("N"))
try {
    [System.IO.File]::WriteAllText($probe, "x")
    Remove-Item -LiteralPath $probe -Force
} catch {
    Fail ("$GameDir cannot be written to. Arcanum CE keeps its saves and settings in the game folder, " +
          "so it needs a folder you can write to - for example, install Arcanum with GOG's offline " +
          "installer to C:\GOG Games\Arcanum (its default), or move the game out of Program Files.")
}

# --- the optional mods ----------------------------------------------------------

$Manifest = Join-Path $GameDir $ManifestName
$upgrade = Test-Path -LiteralPath $Manifest

$modList = @()
foreach ($line in @(Get-Content -LiteralPath (Join-Path $Here "mods.txt"))) {
    if (-not $line -or $line.StartsWith("#")) { continue }
    $fields = $line.Split("`t")
    $modList += , @($fields[0], $fields[1], $fields[2], $fields[3])
}
$ids = @($modList | ForEach-Object { $_[0] })
foreach ($id in $Mod) {
    if ($ids -notcontains $id) { Fail "no optional mod called $id (there are: $($ids -join ', '))" }
}
# $null: leave the settings' mod lines as they are (an update, or -Yes).
$onMods = $null
if ($AllMods) {
    $onMods = $ids
} elseif ($Mod.Count -gt 0) {
    $onMods = $Mod
} elseif (-not $Yes) {
    # What each mod is set to now: an update starts each question there.
    $current = @{}
    $existing = Join-Path $GameDir "arcanum-ce.cfg"
    if ($upgrade -and (Test-Path -LiteralPath $existing)) {
        foreach ($line in @(Get-Content -LiteralPath $existing)) {
            if ($line -match '^mod (.+)=1$') { $current[$Matches[1]] = $true }
        }
    }
    # What every switch does, and which the three answers turn on (zsogg,
    # 2026-10-17): rendered at package time from release/switches.txt, and
    # checked there against the engine and the mods (plain ASCII).
    Say ""
    Get-Content -LiteralPath (Join-Path $Here "setup-summary.txt") |
        ForEach-Object { Write-Host $_ }
    Say ""
    Say ("Arcanum CE comes with " + $modList.Count + " optional mods, each off unless you turn it on:")
    $onMods = @()
    foreach ($m in $modList) {
        Say ""
        Say ("  " + $m[1] + ": " + $m[2] + ".")
        if (Ask $m[3] ($current[$m[0]] -eq $true)) { $onMods += $m[0] }
    }
}

# --- install -------------------------------------------------------------------

Say ("  " + $(if ($upgrade) { "updating" } else { "installing" }) + " Arcanum CE in $GameDir")

$owned = New-Object System.Collections.Generic.List[string]
function Install-File([string]$From, [string]$To) {
    Copy-Item -LiteralPath (Join-Path $Here $From) -Destination (Join-Path $GameDir $To) -Force
    $owned.Add($To)
}

Install-File "arcanum-ce.exe" "arcanum-ce.exe"
Install-File "uninstall.ps1" "arcanum-ce-uninstall.ps1"
Install-File "uninstall.bat" "arcanum-ce-uninstall.bat"
foreach ($doc in @("README.md", "CHANGES.md", "LICENSE.md", "THIRD-PARTY-NOTICES.md")) {
    if (Test-Path -LiteralPath (Join-Path $Here $doc)) { Install-File $doc ("arcanum-ce-" + $doc) }
}
$mods = Join-Path $GameDir "ce-mods"
if (Test-Path -LiteralPath (Join-Path $Here "ce-mods")) {
    if (Test-Path -LiteralPath $mods) { Remove-Item -LiteralPath $mods -Recurse -Force }
    Copy-Item -LiteralPath (Join-Path $Here "ce-mods") -Destination $mods -Recurse -Force
    $owned.Add("ce-mods")
}
# Files from a downloaded zip carry the internet zone mark; clear it on what
# was just copied so Windows does not ask again for each one.
foreach ($rel in $owned) {
    try {
        Get-ChildItem -LiteralPath (Join-Path $GameDir $rel) -Recurse -File -ErrorAction SilentlyContinue |
            Unblock-File -ErrorAction SilentlyContinue
    } catch { }
}

# CE's own settings: on a fresh install the original's arcanum.cfg with the
# release's lines laid over it; on an update the player's file is kept and
# only keys it lacks are added. The original's arcanum.cfg is never touched.
$cfg = Join-Path $GameDir "arcanum-ce.cfg"
$base = @(Get-Content -LiteralPath (Join-Path $Here "arcanum-ce.base.cfg") |
    Where-Object { $_ -and -not $_.StartsWith("#") })
if (Test-Path -LiteralPath $cfg) {
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($line in @(Get-Content -LiteralPath $cfg)) { $lines.Add($line) }
    $overwrite = $false
} else {
    $lines = New-Object System.Collections.Generic.List[string]
    $original = Join-Path $GameDir "arcanum.cfg"
    if (Test-Path -LiteralPath $original) {
        foreach ($line in @(Get-Content -LiteralPath $original)) { $lines.Add($line) }
    }
    $overwrite = $true
}
foreach ($line in $base) {
    $key = $line.Split("=")[0]
    $index = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].StartsWith("$key=")) { $index = $i; break }
    }
    if ($index -lt 0) { $lines.Add($line) }
    elseif ($overwrite) { $lines[$index] = $line }
}
if ($null -ne $onMods) {
    foreach ($id in $ids) {
        $value = $(if ($onMods -contains $id) { "1" } else { "0" })
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i].StartsWith("mod $id=")) { $lines[$i] = "mod $id=$value" }
        }
    }
}
[System.IO.File]::WriteAllLines($cfg, $lines.ToArray())
$owned.Add("arcanum-ce.cfg")

# --- check ------------------------------------------------------------------------

function Invoke-CE([string]$Argument) {
    # The report goes to a file in the game folder, not %TEMP%, and is removed.
    $out = Join-Path $GameDir ".arcanum-ce-check.txt"
    $exe = Join-Path $GameDir "arcanum-ce.exe"
    # A test hook, not a supported route: run the exe through another program.
    if ($env:ARCANUM_SETUP_RUNNER) {
        $process = Start-Process -FilePath $env:ARCANUM_SETUP_RUNNER -ArgumentList @("`"$exe`"", $Argument) `
            -WorkingDirectory $GameDir -RedirectStandardOutput $out -NoNewWindow -Wait -PassThru
    } else {
        $process = Start-Process -FilePath $exe -ArgumentList $Argument `
            -WorkingDirectory $GameDir -RedirectStandardOutput $out -NoNewWindow -Wait -PassThru
    }
    Get-Content -LiteralPath $out | ForEach-Object { Say "  $_" }
    Remove-Item -LiteralPath $out -Force
    return $process.ExitCode
}

Say "Checking the installation..."
$check = Invoke-CE "-check-install"
if ($check -eq 1) {
    if (Ask "Move the loose prototypes that hide UAP's fixes aside (they can be moved back)?" $true) {
        Invoke-CE "-check-install-fix" | Out-Null
    }
} elseif ($check -ne 0) {
    Fail "the installation check failed (exit $check)"
}

# --- shortcuts -----------------------------------------------------------------------

function New-Shortcut([string]$Path) {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($Path)
    $link.TargetPath = Join-Path $GameDir "arcanum-ce.exe"
    $link.WorkingDirectory = $GameDir
    $link.IconLocation = (Join-Path $GameDir "Arcanum.exe") + ",0"
    $link.Description = "Arcanum: Of Steamworks and Magick Obscura - Community Edition"
    $link.Save()
    $owned.Add("shortcut:" + $Path)
}

# Only on request: a shortcut is the one thing outside the game folder.
try {
    if ($StartMenuShortcut) {
        New-Shortcut (Join-Path ([Environment]::GetFolderPath("Programs")) "Arcanum CE.lnk")
        Say "  Start menu: Arcanum CE"
    }
    if ($DesktopShortcut) {
        New-Shortcut (Join-Path ([Environment]::GetFolderPath("Desktop")) "Arcanum CE.lnk")
        Say "  desktop: Arcanum CE"
    }
} catch {
    Say "  note: no shortcut was made ($($_.Exception.Message)); start arcanum-ce.exe in the game folder."
}

# Merge with an earlier install's record, so an update still uninstalls fully.
if ($upgrade) {
    foreach ($entry in Get-Content -LiteralPath $Manifest) {
        if ($entry -and -not $owned.Contains($entry)) { $owned.Add($entry) }
    }
}
[System.IO.File]::WriteAllLines($Manifest, $owned.ToArray())

Say ""
Say "Done. Start Arcanum CE by running arcanum-ce.exe in $GameDir."
Say "Its saves go to $GameDir\modules\Arcanum\SaveCE; its settings are in arcanum-ce.cfg."
$enabled = @(Get-Content -LiteralPath $cfg | Where-Object { $_ -match '^mod (.+)=1$' } | ForEach-Object { $_.Substring(4, $_.Length - 6) })
if ($enabled.Count -gt 0) { Say ("Optional mods on: " + ($enabled -join ", ")) }
else { Say "Optional mods: all off (each is a line in arcanum-ce.cfg)." }
Say "The original Arcanum.exe is unchanged and still plays with its own saves."
Say "To remove Arcanum CE, run arcanum-ce-uninstall.bat in the game folder."
if (-not $Yes) { Read-Host "Press Enter to close" | Out-Null }
