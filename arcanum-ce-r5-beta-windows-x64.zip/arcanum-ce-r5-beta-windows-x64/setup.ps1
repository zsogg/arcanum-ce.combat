# Arcanum CE - Windows setup (release 1, R8).
#
# Installs Arcanum CE into an existing Arcanum folder: Arcanum 1.0.7.4 from GOG
# or Steam (ST2), with the Unofficial Arcanum Patch 2.0.2 (and its High
# Resolution Patch) already installed the usual way. The original Arcanum.exe and its saves are left as
# they are; CE keeps its own saves (modules\Arcanum\SaveCE) and settings
# (arcanum-ce.cfg).
#
# Nothing outside the game folder is written - no registry value, no file in
# the user's profile or %TEMP% - unless the player asks for a shortcut:
# -StartMenuShortcut and -DesktopShortcut each add one .lnk, which the
# uninstaller removes. (Windows PowerShell keeps its own caches under
# %LOCALAPPDATA% whenever any script runs; that is PowerShell's, not this.)
#
#   setup.bat                          (double-click; finds the game folder)
#   setup.bat -GameDir "C:\GOG Games\Arcanum" [-AllMods | -Mod ID,...]
#             [-StartMenuShortcut] [-DesktopShortcut] [-Yes]
#
# Every run shows what each switch does and asks about each optional mod in
# turn (mods.txt's questions): on a first install every answer defaults to
# no, on an update to the mod's current setting. -AllMods or -Mod answer in
# advance; -Yes with neither keeps the settings as they are (all off on a
# first install).
#
# Written for Windows PowerShell 5.1, which every Windows 10 and 11 has.
[CmdletBinding()]
param(
    [string]$GameDir = "",
    [switch]$AllMods,
    [string[]]$Mod = @(),
    [switch]$StartMenuShortcut,
    [switch]$DesktopShortcut,
    [switch]$Yes
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestName = ".arcanum-ce-install"

function Say([string]$Text) { Write-Host $Text }
function Fail([string]$Text) {
    Write-Host ""
    Write-Host "setup: $Text" -ForegroundColor Red
    if (-not $Yes) { Read-Host "Press Enter to close" | Out-Null }
    exit 1
}
function Ask([string]$Question, [bool]$Default = $false) {
    if ($Yes) { return $true }
    $hint = $(if ($Default) { "[Y/n]" } else { "[y/N]" })
    while ($true) {
        # "$(...)" is a string even when Read-Host returns $null at the end of
        # redirected input; [string]$null stays $null (r2-test1, 2026-10-29).
        $answer = "$(Read-Host "$Question $hint")".Trim().ToLower()
        if ($answer -eq "") { return $Default }
        if ($answer -match '^(y|yes)$') { return $true }
        if ($answer -match '^(n|no)$') { return $false }
        Say "  Please answer y or n."
    }
}

# --- the package -------------------------------------------------------------

foreach ($name in @("arcanum-ce.exe", "arcanum-ce.base.cfg", "mods.txt", "setup-summary.txt", "uninstall.ps1", "uninstall.bat")) {
    if (-not (Test-Path -LiteralPath (Join-Path $Here $name))) {
        Fail "the package is incomplete: $name is missing beside setup.ps1"
    }
}

# --- the game folder ----------------------------------------------------------

function Test-GameDir([string]$Dir) {
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    # Join-Path throws on a drive that does not exist (a registry entry left
    # pointing at a removed drive): that is simply not the game folder.
    try {
        return (Test-Path -LiteralPath (Join-Path $Dir "tig.dat")) -and
               (Test-Path -LiteralPath (Join-Path $Dir "Arcanum.exe"))
    } catch { return $false }
}

# Steam keeps the game one folder down, in Arcanum\ beside Sierra's launcher
# (ST2, measured 2026-11-06): the folder Steam's "Browse local files" opens,
# and the one its Sierra registry key names, is the one above the game.
function Resolve-GameDir([string]$Dir) {
    if (Test-GameDir $Dir) { return $Dir }
    try {
        $inner = Join-Path $Dir "Arcanum"
        if (Test-GameDir $inner) { return $inner }
    } catch { }
    return $Dir
}

# A Steam folder and every library its steamapps\libraryfolders.vdf lists:
# the current format's "path" lines, and the older format's numbered lines
# whose value is a path. Escaped backslashes are undone.
function Get-SteamLibraries([string]$SteamDir) {
    $libraries = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrWhiteSpace($SteamDir)) { return ,$libraries }
    $libraries.Add($SteamDir.TrimEnd('\'))
    try {
        $vdf = Join-Path (Join-Path $SteamDir "steamapps") "libraryfolders.vdf"
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in @(Get-Content -LiteralPath $vdf)) {
                if ($line -match '^\s*"(path|\d+)"\s+"(.+)"\s*$') {
                    $value = $Matches[2].Replace('\\', '\')
                    if ($value.Contains('\') -or $value.Contains('/')) {
                        $value = $value.TrimEnd('\')
                        if (-not $libraries.Contains($value)) { $libraries.Add($value) }
                    }
                }
            }
        }
    } catch { }
    return ,$libraries
}

# Where Arcanum would be in each Steam library of each Steam folder given.
function Get-SteamGameCandidates([string[]]$SteamDirs) {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($steam in $SteamDirs) {
        foreach ($library in (Get-SteamLibraries $steam)) {
            try {
                $dir = Join-Path (Join-Path (Join-Path $library "steamapps") "common") "Arcanum"
                if (-not $candidates.Contains($dir)) { $candidates.Add($dir) }
            } catch { }
        }
    }
    return ,$candidates
}

# Every distinct Arcanum folder among the candidates, in their order: one PC
# can hold GOG's copy and Steam's at once (zsogg, 2026-11-07).
function Get-GameDirs([string[]]$Candidates) {
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($dir in $Candidates) {
        $game = (Resolve-GameDir $dir).TrimEnd('\')
        if ((Test-GameDir $game) -and -not ($found -contains $game)) { $found.Add($game) }
    }
    return $found.ToArray()
}

# Lists the folders and asks which one: a number, or another folder typed in.
# "" when nothing is typed (Enter, or the end of redirected input).
function Select-GameDir([string[]]$Dirs) {
    Write-Host "  Arcanum is in more than one folder:"
    for ($i = 0; $i -lt $Dirs.Count; $i++) {
        $note = $(if (Test-Path -LiteralPath (Join-Path $Dirs[$i] $ManifestName)) { " (Arcanum CE is installed here)" } else { "" })
        Write-Host "    $($i + 1). $($Dirs[$i])$note"
    }
    while ($true) {
        $answer = "$(Read-Host "Which one? Type its number, or another folder")".Trim().Trim('"')
        if ($answer -notmatch '^\d{1,3}$') { return $answer }
        if ([int]$answer -ge 1 -and [int]$answer -le $Dirs.Count) { return $Dirs[[int]$answer - 1] }
        Write-Host "  Please type a number from 1 to $($Dirs.Count)."
    }
}

function Find-GameDirs {
    $candidates = New-Object System.Collections.Generic.List[string]
    # Read only: GOG's key, the CD's Sierra key, and the Sierra key Steam's
    # install script writes (its InstallPath is the folder above the game).
    $keys = @(
        @("HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra\Arcanum", "InstallPath"),
        @("HKLM:\SOFTWARE\Sierra\Arcanum", "InstallPath")
    )
    foreach ($key in $keys) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key[0] -ErrorAction Stop).($key[1])
            if ($value) { $candidates.Add($value.TrimEnd('\')) }
        } catch { }
    }
    foreach ($dir in @("C:\GOG Games\Arcanum", "C:\GOG Games\Arcanum - Of Steamworks and Magick Obscura",
                       "C:\Program Files (x86)\GOG Galaxy\Games\Arcanum",
                       "C:\Program Files (x86)\GOG.com\Arcanum")) {
        $candidates.Add($dir)
    }
    # Steam: its own install path (machine-wide, read only), then its usual
    # folders; each library from its libraryfolders.vdf.
    $steamDirs = New-Object System.Collections.Generic.List[string]
    foreach ($key in @("HKLM:\SOFTWARE\WOW6432Node\Valve\Steam", "HKLM:\SOFTWARE\Valve\Steam")) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).InstallPath
            if ($value) { $steamDirs.Add($value) }
        } catch { }
    }
    $steamDirs.Add("C:\Program Files (x86)\Steam")
    $steamDirs.Add("C:\Program Files\Steam")
    foreach ($dir in (Get-SteamGameCandidates $steamDirs.ToArray())) { $candidates.Add($dir) }
    return Get-GameDirs $candidates.ToArray()
}

Say "Arcanum CE setup"
if (-not $GameDir) {
    $found = @(Find-GameDirs)
    if ($found.Count -gt 1) {
        if ($Yes) { Fail "Arcanum is in more than one folder ($($found -join '; ')). Name one with -GameDir." }
        $GameDir = Select-GameDir $found
    } elseif ($found.Count -eq 1) {
        $GameDir = $found[0]
        Say "  found Arcanum in $GameDir"
        if (-not (Ask "Install Arcanum CE there?" $true)) {
            $GameDir = Read-Host "The folder Arcanum is installed in"
        }
    } elseif (-not $Yes) {
        $GameDir = Read-Host "Arcanum was not found. The folder it is installed in"
    }
}
$GameDir = $GameDir.Trim().Trim('"').TrimEnd('\')
$resolved = Resolve-GameDir $GameDir
if ($resolved -ne $GameDir) {
    Say "  using the game folder inside it, $resolved"
    $GameDir = $resolved
}
if (-not (Test-GameDir $GameDir)) {
    Fail "'$GameDir' is not an Arcanum folder (no tig.dat and Arcanum.exe). Install Arcanum from GOG or Steam first."
}

# The archives' spellings (GOG's and Steam's are the same); nested Join-Path rather than "\" so the script's logic
# can also be tested where paths are case-sensitive and "/"-separated.
foreach ($name in @("arcanum1.dat", "arcanum2.dat", "arcanum3.dat", "Arcanum4.dat", "modules/Arcanum.dat")) {
    $path = $GameDir
    foreach ($part in $name.Split("/")) { $path = Join-Path $path $part }
    if (-not (Test-Path -LiteralPath $path)) {
        Fail "the base game is incomplete: $name is missing in $GameDir"
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $GameDir "Arcanum5.dat"))) {
    Fail "the Unofficial Arcanum Patch is not installed in $GameDir (no Arcanum5.dat). Run UAP2.0.2.exe first, installing into this folder."
}
if (-not (Test-Path -LiteralPath (Join-Path (Join-Path $GameDir "HighRes") "config.ini"))) {
    Say "  note: the High Resolution Patch is not installed; CE will use the original 800x600."
}

# CE is a 64-bit program, and Windows does not redirect a 64-bit program's
# writes out of Program Files as it does the original's - so a folder the
# player cannot write to cannot hold CE's saves and settings.
$probe = Join-Path $GameDir (".arcanum-ce-write-test-" + [Guid]::NewGuid().ToString("N"))
try {
    [System.IO.File]::WriteAllText($probe, "x")
    Remove-Item -LiteralPath $probe -Force
} catch {
    Fail ("$GameDir cannot be written to. Arcanum CE keeps its saves and settings in the game folder, " +
          "so it needs a folder you can write to - for example, install Arcanum with GOG's offline " +
          "installer to C:\GOG Games\Arcanum (its default), or move the game out of Program Files. " +
          "With Steam: add a library folder outside Program Files (Steam, Settings, Storage) and move Arcanum there.")
}

# --- the optional mods ----------------------------------------------------------

$Manifest = Join-Path $GameDir $ManifestName
$upgrade = Test-Path -LiteralPath $Manifest

$modList = @()
foreach ($line in @(Get-Content -LiteralPath (Join-Path $Here "mods.txt"))) {
    if (-not $line -or $line.StartsWith("#")) { continue }
    $fields = $line.Split("`t")
    $modList += , @($fields[0], $fields[1], $fields[2], $fields[3])
}
$ids = @($modList | ForEach-Object { $_[0] })
foreach ($id in $Mod) {
    if ($ids -notcontains $id) { Fail "no optional mod called $id (there are: $($ids -join ', '))" }
}
# $null: leave the settings' mod lines as they are (an update, or -Yes).
$onMods = $null
if ($AllMods) {
    $onMods = $ids
} elseif ($Mod.Count -gt 0) {
    $onMods = $Mod
} elseif (-not $Yes) {
    # What each mod is set to now: an update starts each question there.
    $current = @{}
    $existing = Join-Path $GameDir "arcanum-ce.cfg"
    if ($upgrade -and (Test-Path -LiteralPath $existing)) {
        foreach ($line in @(Get-Content -LiteralPath $existing)) {
            if ($line -match '^mod (.+)=1$') { $current[$Matches[1]] = $true }
        }
    }
    # What every switch does, and which the three answers turn on (zsogg,
    # 2026-10-17): rendered at package time from release/switches.txt, and
    # checked there against the engine and the mods (plain ASCII).
    Say ""
    Get-Content -LiteralPath (Join-Path $Here "setup-summary.txt") |
        ForEach-Object { Write-Host $_ }
    Say ""
    Say ("Arcanum CE comes with " + $modList.Count + " optional mods, each off unless you turn it on:")
    $onMods = @()
    foreach ($m in $modList) {
        Say ""
        Say ("  " + $m[1] + ": " + $m[2] + ".")
        if (Ask $m[3] ($current[$m[0]] -eq $true)) { $onMods += $m[0] }
    }
}

# --- install -------------------------------------------------------------------

Say ("  " + $(if ($upgrade) { "updating" } else { "installing" }) + " Arcanum CE in $GameDir")

$owned = New-Object System.Collections.Generic.List[string]
# The record is written before each copy, not once at the end: a copy or a
# check that fails (antivirus taking the exe) left files the uninstaller
# would not remove (review 2026-10-31, finding 12). It merges with an
# earlier install's record, so an update still uninstalls fully.
function Save-Manifest {
    $all = New-Object System.Collections.Generic.List[string]
    foreach ($entry in $owned) { $all.Add($entry) }
    if (Test-Path -LiteralPath $Manifest) {
        foreach ($entry in Get-Content -LiteralPath $Manifest) {
            if ($entry -and -not $all.Contains($entry)) { $all.Add($entry) }
        }
    }
    [System.IO.File]::WriteAllLines($Manifest, $all.ToArray())
}
function Own([string]$Entry) {
    $owned.Add($Entry)
    Save-Manifest
}
function Install-File([string]$From, [string]$To) {
    Own $To
    Copy-Item -LiteralPath (Join-Path $Here $From) -Destination (Join-Path $GameDir $To) -Force
}

Install-File "arcanum-ce.exe" "arcanum-ce.exe"
Install-File "uninstall.ps1" "arcanum-ce-uninstall.ps1"
Install-File "uninstall.bat" "arcanum-ce-uninstall.bat"
foreach ($doc in @("README.md", "CHANGES.md", "LICENSE.md", "THIRD-PARTY-NOTICES.md")) {
    if (Test-Path -LiteralPath (Join-Path $Here $doc)) { Install-File $doc ("arcanum-ce-" + $doc) }
}
$mods = Join-Path $GameDir "ce-mods"
if (Test-Path -LiteralPath (Join-Path $Here "ce-mods")) {
    Own "ce-mods"
    if (Test-Path -LiteralPath $mods) { Remove-Item -LiteralPath $mods -Recurse -Force }
    Copy-Item -LiteralPath (Join-Path $Here "ce-mods") -Destination $mods -Recurse -Force
}
# Files from a downloaded zip carry the internet zone mark; clear it on what
# was just copied so Windows does not ask again for each one.
foreach ($rel in $owned) {
    try {
        Get-ChildItem -LiteralPath (Join-Path $GameDir $rel) -Recurse -File -ErrorAction SilentlyContinue |
            Unblock-File -ErrorAction SilentlyContinue
    } catch { }
}

# CE's own settings: on a fresh install the original's arcanum.cfg with the
# release's lines laid over it; on an update the player's file is kept and
# only keys it lacks are added. The original's arcanum.cfg is never touched.
$cfg = Join-Path $GameDir "arcanum-ce.cfg"
$base = @(Get-Content -LiteralPath (Join-Path $Here "arcanum-ce.base.cfg") |
    Where-Object { $_ -and -not $_.StartsWith("#") })
if (Test-Path -LiteralPath $cfg) {
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($line in @(Get-Content -LiteralPath $cfg)) { $lines.Add($line) }
    $overwrite = $false
} else {
    $lines = New-Object System.Collections.Generic.List[string]
    $original = Join-Path $GameDir "arcanum.cfg"
    if (Test-Path -LiteralPath $original) {
        foreach ($line in @(Get-Content -LiteralPath $original)) { $lines.Add($line) }
    }
    $overwrite = $true
}
foreach ($line in $base) {
    $key = $line.Split("=")[0]
    $index = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].StartsWith("$key=")) { $index = $i; break }
    }
    if ($index -lt 0) { $lines.Add($line) }
    elseif ($overwrite) { $lines[$index] = $line }
}
if ($null -ne $onMods) {
    foreach ($id in $ids) {
        $value = $(if ($onMods -contains $id) { "1" } else { "0" })
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i].StartsWith("mod $id=")) { $lines[$i] = "mod $id=$value" }
        }
    }
}
Own "arcanum-ce.cfg"
[System.IO.File]::WriteAllLines($cfg, $lines.ToArray())

# --- check ------------------------------------------------------------------------

function Invoke-CE([string]$Argument) {
    # The report goes to a file in the game folder, not %TEMP%, and is removed.
    $out = Join-Path $GameDir ".arcanum-ce-check.txt"
    $exe = Join-Path $GameDir "arcanum-ce.exe"
    # A test hook, not a supported route: run the exe through another program.
    if ($env:ARCANUM_SETUP_RUNNER) {
        $process = Start-Process -FilePath $env:ARCANUM_SETUP_RUNNER -ArgumentList @("`"$exe`"", $Argument) `
            -WorkingDirectory $GameDir -RedirectStandardOutput $out -NoNewWindow -Wait -PassThru
    } else {
        $process = Start-Process -FilePath $exe -ArgumentList $Argument `
            -WorkingDirectory $GameDir -RedirectStandardOutput $out -NoNewWindow -Wait -PassThru
    }
    Get-Content -LiteralPath $out | ForEach-Object { Say "  $_" }
    Remove-Item -LiteralPath $out -Force
    return $process.ExitCode
}

Say "Checking the installation..."
$check = Invoke-CE "-check-install"
if ($check -eq 1) {
    if (Ask "Move the loose prototypes that hide UAP's fixes aside (they can be moved back)?" $true) {
        Invoke-CE "-check-install-fix" | Out-Null
    }
} elseif ($check -ne 0) {
    Fail "the installation check failed (exit $check)"
}

# --- shortcuts -----------------------------------------------------------------------

function New-Shortcut([string]$Path) {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($Path)
    $link.TargetPath = Join-Path $GameDir "arcanum-ce.exe"
    $link.WorkingDirectory = $GameDir
    $link.IconLocation = (Join-Path $GameDir "Arcanum.exe") + ",0"
    $link.Description = "Arcanum: Of Steamworks and Magick Obscura - Community Edition"
    $link.Save()
    Own ("shortcut:" + $Path)
}

# Only on request: a shortcut is the one thing outside the game folder.
try {
    if ($StartMenuShortcut) {
        New-Shortcut (Join-Path ([Environment]::GetFolderPath("Programs")) "Arcanum CE.lnk")
        Say "  Start menu: Arcanum CE"
    }
    if ($DesktopShortcut) {
        New-Shortcut (Join-Path ([Environment]::GetFolderPath("Desktop")) "Arcanum CE.lnk")
        Say "  desktop: Arcanum CE"
    }
} catch {
    Say "  note: no shortcut was made ($($_.Exception.Message)); start arcanum-ce.exe in the game folder."
}


Say ""
Say "Done. Start Arcanum CE by running arcanum-ce.exe in $GameDir."
Say "Its saves go to $GameDir\modules\Arcanum\SaveCE; its settings are in arcanum-ce.cfg."
$enabled = @(Get-Content -LiteralPath $cfg | Where-Object { $_ -match '^mod (.+)=1$' } | ForEach-Object { $_.Substring(4, $_.Length - 6) })
if ($enabled.Count -gt 0) { Say ("Optional mods on: " + ($enabled -join ", ")) }
else { Say "Optional mods: all off (each is a line in arcanum-ce.cfg)." }
Say "The original Arcanum.exe is unchanged and still plays with its own saves."
Say "To remove Arcanum CE, run arcanum-ce-uninstall.bat in the game folder."
if (-not $Yes) { Read-Host "Press Enter to close" | Out-Null }
