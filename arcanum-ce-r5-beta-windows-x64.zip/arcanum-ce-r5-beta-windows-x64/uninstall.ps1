# Arcanum CE - remove what setup.ps1 installed (release 1, R8).
#
# Removes Arcanum CE's files from the game folder and any shortcut setup made.
# The game, the original Arcanum.exe, its saves and CE's saves
# (modules\Arcanum\SaveCE) are left in place.
#
# Runs from the game folder (arcanum-ce-uninstall.bat, installed by setup) or
# from the unzipped package (uninstall.bat), which finds the game folder as
# setup does. Asks first, then says "Uninstall in progress...", then
# "Uninstall complete.", then waits for Enter (zsogg, 2026-10-17). -Yes skips
# the question and the wait. -FromBatch is the .bat's: the .bat waits for
# Enter itself, so the window stays open even if PowerShell fails.
#
#   arcanum-ce-uninstall.bat [-GameDir DIR] [-Yes]
[CmdletBinding()]
param(
    [string]$GameDir = "",
    [switch]$Yes,
    [switch]$FromBatch
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestName = ".arcanum-ce-install"

# The window a double-click opens closes when the script ends: every way out
# waits for Enter first, so the last message can be read.
function Finish([int]$Code) {
    if (-not $Yes -and -not $FromBatch) { Read-Host "Press Enter to exit the uninstaller" | Out-Null }
    exit $Code
}

# --- the game folder (as setup.ps1 finds it) ----------------------------------

function Test-GameDir([string]$Dir) {
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    # Join-Path throws on a drive that does not exist (a registry entry left
    # pointing at a removed drive): that is simply not the game folder.
    try {
        return (Test-Path -LiteralPath (Join-Path $Dir "tig.dat")) -and
               (Test-Path -LiteralPath (Join-Path $Dir "Arcanum.exe"))
    } catch { return $false }
}

# Steam keeps the game one folder down, in Arcanum\ beside Sierra's launcher
# (ST2, measured 2026-11-06): the folder Steam's "Browse local files" opens,
# and the one its Sierra registry key names, is the one above the game.
function Resolve-GameDir([string]$Dir) {
    if (Test-GameDir $Dir) { return $Dir }
    try {
        $inner = Join-Path $Dir "Arcanum"
        if (Test-GameDir $inner) { return $inner }
    } catch { }
    return $Dir
}

# A Steam folder and every library its steamapps\libraryfolders.vdf lists:
# the current format's "path" lines, and the older format's numbered lines
# whose value is a path. Escaped backslashes are undone.
function Get-SteamLibraries([string]$SteamDir) {
    $libraries = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrWhiteSpace($SteamDir)) { return ,$libraries }
    $libraries.Add($SteamDir.TrimEnd('\'))
    try {
        $vdf = Join-Path (Join-Path $SteamDir "steamapps") "libraryfolders.vdf"
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in @(Get-Content -LiteralPath $vdf)) {
                if ($line -match '^\s*"(path|\d+)"\s+"(.+)"\s*$') {
                    $value = $Matches[2].Replace('\\', '\')
                    if ($value.Contains('\') -or $value.Contains('/')) {
                        $value = $value.TrimEnd('\')
                        if (-not $libraries.Contains($value)) { $libraries.Add($value) }
                    }
                }
            }
        }
    } catch { }
    return ,$libraries
}

# Where Arcanum would be in each Steam library of each Steam folder given.
function Get-SteamGameCandidates([string[]]$SteamDirs) {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($steam in $SteamDirs) {
        foreach ($library in (Get-SteamLibraries $steam)) {
            try {
                $dir = Join-Path (Join-Path (Join-Path $library "steamapps") "common") "Arcanum"
                if (-not $candidates.Contains($dir)) { $candidates.Add($dir) }
            } catch { }
        }
    }
    return ,$candidates
}

# Every distinct Arcanum folder among the candidates, in their order: one PC
# can hold GOG's copy and Steam's at once (zsogg, 2026-11-07).
function Get-GameDirs([string[]]$Candidates) {
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($dir in $Candidates) {
        $game = (Resolve-GameDir $dir).TrimEnd('\')
        if ((Test-GameDir $game) -and -not ($found -contains $game)) { $found.Add($game) }
    }
    return $found.ToArray()
}

# Lists the folders and asks which one: a number, or another folder typed in.
# "" when nothing is typed (Enter, or the end of redirected input).
function Select-GameDir([string[]]$Dirs) {
    Write-Host "  Arcanum is in more than one folder:"
    for ($i = 0; $i -lt $Dirs.Count; $i++) {
        $note = $(if (Test-Path -LiteralPath (Join-Path $Dirs[$i] $ManifestName)) { " (Arcanum CE is installed here)" } else { "" })
        Write-Host "    $($i + 1). $($Dirs[$i])$note"
    }
    while ($true) {
        $answer = "$(Read-Host "Which one? Type its number, or another folder")".Trim().Trim('"')
        if ($answer -notmatch '^\d{1,3}$') { return $answer }
        if ([int]$answer -ge 1 -and [int]$answer -le $Dirs.Count) { return $Dirs[[int]$answer - 1] }
        Write-Host "  Please type a number from 1 to $($Dirs.Count)."
    }
}

function Find-GameDirs {
    $candidates = New-Object System.Collections.Generic.List[string]
    # Read only: GOG's key, the CD's Sierra key, and the Sierra key Steam's
    # install script writes (its InstallPath is the folder above the game).
    $keys = @(
        @("HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\GOG.com\Games\1207658829", "path"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\Sierra OnLine\Setup\AR_USENG", "Directory"),
        @("HKLM:\SOFTWARE\WOW6432Node\Sierra\Arcanum", "InstallPath"),
        @("HKLM:\SOFTWARE\Sierra\Arcanum", "InstallPath")
    )
    foreach ($key in $keys) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key[0] -ErrorAction Stop).($key[1])
            if ($value) { $candidates.Add($value.TrimEnd('\')) }
        } catch { }
    }
    foreach ($dir in @("C:\GOG Games\Arcanum", "C:\GOG Games\Arcanum - Of Steamworks and Magick Obscura",
                       "C:\Program Files (x86)\GOG Galaxy\Games\Arcanum",
                       "C:\Program Files (x86)\GOG.com\Arcanum")) {
        $candidates.Add($dir)
    }
    # Steam: its own install path (machine-wide, read only), then its usual
    # folders; each library from its libraryfolders.vdf.
    $steamDirs = New-Object System.Collections.Generic.List[string]
    foreach ($key in @("HKLM:\SOFTWARE\WOW6432Node\Valve\Steam", "HKLM:\SOFTWARE\Valve\Steam")) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).InstallPath
            if ($value) { $steamDirs.Add($value) }
        } catch { }
    }
    $steamDirs.Add("C:\Program Files (x86)\Steam")
    $steamDirs.Add("C:\Program Files\Steam")
    foreach ($dir in (Get-SteamGameCandidates $steamDirs.ToArray())) { $candidates.Add($dir) }
    return Get-GameDirs $candidates.ToArray()
}

# --- end of what setup.ps1 shares ---------------------------------------------

Write-Host "Arcanum CE uninstall"
# Run from the game folder itself (the installed copy), rather than the package.
$InGameDir = Test-Path -LiteralPath (Join-Path $Here $ManifestName)
if (-not $GameDir) {
    if ($InGameDir) {
        $GameDir = $Here
    } else {
        $found = @(Find-GameDirs | Where-Object { Test-Path -LiteralPath (Join-Path $_ $ManifestName) })
        if ($found.Count -eq 1) {
            $GameDir = $found[0]
        } elseif ($found.Count -gt 1) {
            if ($Yes) {
                Write-Host "Arcanum CE is installed in more than one folder ($($found -join '; ')). Name one with -GameDir. Nothing was removed." -ForegroundColor Red
                Finish 1
            }
            $GameDir = Select-GameDir $found
        } elseif (-not $Yes) {
            $GameDir = [string](Read-Host "Arcanum CE was not found. The folder it is installed in")
        }
    }
}
$GameDir = ([string]$GameDir).Trim().Trim('"').TrimEnd('\')
if ($GameDir) { $GameDir = Resolve-GameDir $GameDir }
$Manifest = $(if ($GameDir) { Join-Path $GameDir $ManifestName } else { "" })
if (-not $Manifest -or -not (Test-Path -LiteralPath $Manifest)) {
    Write-Host "Arcanum CE is not installed in '$GameDir' (it was not set up by Arcanum CE's setup). Nothing was removed." -ForegroundColor Red
    Finish 1
}
Write-Host "  Arcanum CE is installed in $GameDir"
if (-not $Yes) {
    $answer = ""
    while ($answer -notmatch '^(y|yes|n|no)$') {
        $answer = "$(Read-Host "Do you want to uninstall Arcanum CE? Your saves stay. [y/n]")".Trim().ToLower()
    }
    if ($answer -match '^(n|no)$') {
        Write-Host "Nothing was removed."
        Finish 1
    }
}

Write-Host "Uninstall in progress..."
$self = @("arcanum-ce-uninstall.ps1", "arcanum-ce-uninstall.bat")
try {
    foreach ($entry in Get-Content -LiteralPath $Manifest) {
        if (-not $entry) { continue }
        if ($entry.StartsWith("shortcut:")) {
            Remove-Item -LiteralPath $entry.Substring(9) -Force -ErrorAction SilentlyContinue
            continue
        }
        # Only names inside the game folder, never a path that climbs out of it.
        if ($entry.Contains("..") -or [System.IO.Path]::IsPathRooted($entry)) { continue }
        if ($self -contains $entry) { continue }
        $path = Join-Path $GameDir $entry
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    }
    Remove-Item -LiteralPath $Manifest -Force
    # Written by the game, not setup, so not in the record; it is not a save.
    Remove-Item -LiteralPath (Join-Path $GameDir "arcanum-ce.log") -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "The uninstall stopped: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Close Arcanum CE if it is running, then run the uninstaller again."
    Finish 1
}

# The scripts in the game folder go last, once nothing more is read from them.
# A running .bat cannot be deleted under itself: arcanum-ce-uninstall.bat
# removes itself once this script has returned.
Remove-Item -LiteralPath (Join-Path $GameDir "arcanum-ce-uninstall.ps1") -Force -ErrorAction SilentlyContinue
$bat = Join-Path $GameDir "arcanum-ce-uninstall.bat"
if (-not ($FromBatch -and $InGameDir)) {
    Remove-Item -LiteralPath $bat -Force -ErrorAction SilentlyContinue
}
Write-Host "Uninstall complete. Arcanum CE is removed; the game and your saves (modules\Arcanum\SaveCE) remain in $GameDir."
Finish 0
