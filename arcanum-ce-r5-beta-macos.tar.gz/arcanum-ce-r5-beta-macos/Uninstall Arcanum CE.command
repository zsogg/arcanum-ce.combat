#!/bin/bash
# Arcanum CE for macOS: the double-click uninstaller (review 2026-10-31).
#
# setup.sh puts this in the game folder beside arcanum-ce-uninstall.sh.
# Double-clicked, it asks whether to remove Arcanum CE only (the game files
# and saves stay) or the whole folder (saves included, after a second,
# explicit question), runs arcanum-ce-uninstall.sh accordingly, and says what
# it did. The script keeps to bash 3.2, the /bin/bash macOS ships.

set -u
HERE="$(cd "$(dirname "$0")" && pwd -P)"

done_window() {  # done_window CODE: wait, so the window stays open to be read
    printf '\nPress Return to close this window. '
    read -r _ || true
    exit "$1"
}

ask() {  # ask MESSAGE BUTTON...: the button pressed; Cancel (or no dialog) is "Cancel"
    local message="$1"
    shift
    command -v osascript >/dev/null 2>&1 || { printf 'Cancel'; return; }
    osascript -e 'on run argv' -e 'activate' \
        -e 'set b to items 2 thru -1 of argv' \
        -e 'try' \
        -e 'return button returned of (display dialog (item 1 of argv) buttons b default button (count of b) with title "Arcanum CE" with icon caution)' \
        -e 'on error number -128' -e 'return "Cancel"' -e 'end try' \
        -e 'end run' "$message" "$@" 2>/dev/null || printf 'Cancel'
}

echo "Arcanum CE uninstaller"
echo "  game folder: $HERE"
if [ "${EUID:-1}" -eq 0 ]; then
    echo "Run this as yourself, not as root."
    done_window 1
fi
if [ ! -f "$HERE/arcanum-ce-uninstall.sh" ] || [ ! -f "$HERE/.arcanum-ce-install" ]; then
    echo "This folder has no Arcanum CE install to remove (no arcanum-ce-uninstall.sh"
    echo "or no record of what setup installed). Nothing was changed."
    done_window 1
fi

if ! command -v osascript >/dev/null 2>&1; then
    # No dialogs: the shell uninstaller asks in the window itself.
    bash "$HERE/arcanum-ce-uninstall.sh"
    done_window $?
fi

echo "  A dialog asks what to remove."
choice="$(ask "Remove Arcanum CE from $HERE?

Remove Arcanum CE only: the game files and your saves stay in the folder.
Delete everything: the whole folder goes, saves included." \
    "Cancel" "Delete everything..." "Remove Arcanum CE only")"
case "$choice" in
    "Remove Arcanum CE only")
        echo "Removing Arcanum CE; the game files and saves stay..."
        bash "$HERE/arcanum-ce-uninstall.sh"
        done_window $? ;;
    "Delete everything...")
        saves="$(find "$HERE/modules/Arcanum/SaveCE" "$HERE/modules/Arcanum/Save" -type f 2>/dev/null | wc -l | tr -d ' ')"
        echo "  A dialog asks to confirm."
        sure="$(ask "Delete the whole folder, for good?

$HERE
with the game, Arcanum CE and the saves ($saves files).
This cannot be undone." "Cancel" "Delete")"
        if [ "$sure" = "Delete" ]; then
            echo "Deleting $HERE..."
            # The shell uninstaller lists what goes before deleting it.
            bash "$HERE/arcanum-ce-uninstall.sh" --all --yes
            done_window $?
        fi ;;
esac
echo "Nothing was changed."
done_window 0
