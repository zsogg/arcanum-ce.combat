#!/bin/bash
# Arcanum CE for macOS: the double-click installer (MAC2, 2026-10-31).
#
# Double-click this file in Finder. It opens in Terminal and:
#   1. checks the package and clears macOS's download flag from its own files;
#   2. finds GOG's Arcanum installer in Downloads, on the Desktop or beside
#      this folder, or asks for it (or for a game folder from a Windows PC);
#   3. finds the Unofficial Arcanum Patch, UAP2.0.2.exe, the same way;
#   4. picks the game folder, leaving every existing one alone, and checks
#      the free space;
#   5. asks which optional mods to turn on, and to confirm;
#   6. runs setup.sh beside it, then offers to copy saves from an earlier
#      install and to start the game.
# Each step says what it is doing and what it found; questions are dialogs, so
# nothing has to be typed. Everything shown also goes to a log in
# ~/Library/Logs/Arcanum CE/, with this Mac's details for a bug report, the
# home folder's name replaced by ~ and every time in UTC, so the log can be
# attached to a public report as it is.
#
# It is the same as running, in this folder:
#   bash setup.sh --gog <GOG installer> --uap <UAP2.0.2.exe> [--mod ID ...]
# The script keeps to bash 3.2, the /bin/bash macOS ships.

set -u
# Every time in the log, its name included, and in what setup prints: UTC,
# so a log attached to a public report does not give away the time zone.
export TZ=UTC0

printf 'Arcanum CE installer\n'
printf '  (If macOS asks whether Terminal may use your Downloads or Desktop folder, click Allow, or OK.)\n'
HERE="$(cd "$(dirname "$0")" && pwd -P)"
LOG_DIR="$HOME/Library/Logs/Arcanum CE"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/install-$(date +%Y%m%d-%H%M%SZ).log"
OUT="$(mktemp "$LOG_DIR/.setup-output.XXXXXX")"   # one per run: two runs never mix

# What would name the player: the home folder by either spelling (a link may
# lead to it) and the account's full name.
escape() { printf '%s' "$1" | sed 's/[][\.*^$/]/\\&/g'; }
HOME_RE="$(escape "$HOME")"
HOME_REAL_RE="$(escape "$(cd "$HOME" && pwd -P)")"
FULL_NAME="$(id -F 2>/dev/null || true)"
scrub() {
    if [ -n "$FULL_NAME" ]; then
        sed -e "s/$HOME_RE/~/g" -e "s/$HOME_REAL_RE/~/g" -e "s/$(escape "$FULL_NAME")/(the account's name)/g"
    else
        sed -e "s/$HOME_RE/~/g" -e "s/$HOME_REAL_RE/~/g"
    fi
}
log() { printf '%s\n' "$*" | scrub >> "$LOG"; }
say() { printf '%s\n' "$*"; log "$*"; }
step() { say ""; say "== Step $1 of 6: $2"; }
tilde() { printf '%s' "$1" | scrub; }       # a path as shown: ~/Downloads/...
size() { du -h "$1" 2>/dev/null | awk '{print $1}'; }

# Setup's output is kept raw while it runs; whatever ends the installer, a
# closed window included, it reaches the log scrubbed.
keep_output() {
    if [ -s "$OUT" ]; then
        scrub < "$OUT" >> "$LOG"
    fi
    rm -f "$OUT"
}
trap keep_output EXIT
trap 'keep_output; exit 129' HUP

finish() {  # finish CODE: the closing lines, then wait, so the window stays open
    say ""
    if [ "$1" -eq 0 ]; then
        say "The installer has finished."
    elif [ "$1" -eq 130 ]; then
        say "Stopped. Double-click the installer to start again."
    else
        say "The installer stopped. The lines above say why."
        say "Its log, to attach to a bug report: $(tilde "$LOG")"
        say "(It is shown in Finder now; the README's 'Reporting a problem' says where to send it.)"
        command -v open >/dev/null 2>&1 && open -R "$LOG" 2>/dev/null
    fi
    log "--- finished with exit $1, $(date '+%Y-%m-%d %H:%M:%S UTC')"
    printf 'Press Return, then close this window (Cmd-W). '
    read -r _ || true
    exit "$1"
}
trap 'say ""; say "Stopped with Ctrl-C; nothing was installed."; finish 130' INT

# --- asking, by dialog where macOS can show one -------------------------------

have_dialogs() { command -v osascript >/dev/null 2>&1; }

choose() {  # choose file|folder PROMPT: prints the chosen path, or nothing if cancelled
    local what="$1" prompt="$2" path
    if have_dialogs; then
        path="$(osascript -e 'on run argv' -e 'activate' -e 'try' \
            -e 'if item 1 of argv is "folder" then' \
            -e 'return POSIX path of (choose folder with prompt (item 2 of argv) default location (path to downloads folder))' \
            -e 'end if' \
            -e 'return POSIX path of (choose file with prompt (item 2 of argv) default location (path to downloads folder))' \
            -e 'on error number -128' -e 'return ""' -e 'end try' -e 'end run' \
            "$what" "$prompt" 2>/dev/null)" && { log "  chose: $path"; printf '%s' "${path%/}"; return 0; }
    fi
    # No dialog: Terminal types the path of anything dragged into its window.
    printf '  Drag the %s from Finder into this window, then press Return:\n  > ' "$what" >&2
    read -r path || path=""
    path="${path%"${path##*[! ]}"}"    # the space Terminal adds after a dragged path
    path="${path//\\/}"                 # and its backslashes before spaces and brackets
    log "  dragged in: $path"
    printf '%s' "${path%/}"
}

ask() {  # ask MESSAGE BUTTON...: prints the button pressed (the last is the default)
    local message="$1" answer
    shift
    printf '  A dialog asks: %s\n' "${message%%
*}" >&2
    log "  asked: $message"
    if have_dialogs; then
        # A button named Cancel raises error -128 instead of returning: catch
        # it, or a Cancel would read as "no dialogs" and take the default.
        answer="$(osascript -e 'on run argv' -e 'activate' \
            -e 'set b to items 2 thru -1 of argv' \
            -e 'try' \
            -e 'return button returned of (display dialog (item 1 of argv) buttons b default button (count of b) with title "Arcanum CE")' \
            -e 'on error number -128' -e 'return "Cancel"' -e 'end try' \
            -e 'end run' "$message" "$@" 2>/dev/null)" && { log "  answered: $answer"; printf '%s' "$answer"; return 0; }
    fi
    # No dialog: the default, the last button.
    for answer in "$@"; do :; done
    log "  no dialog; took: $answer"
    printf '%s' "$answer"
}

pick() {  # pick PROMPT ITEM...: the item chosen from a list, or "" if cancelled
    local answer
    printf '  A dialog asks: %s\n' "$1" >&2
    if have_dialogs; then
        answer="$(osascript -e 'on run argv' -e 'activate' \
            -e 'set r to choose from list (items 2 thru -1 of argv) with prompt (item 1 of argv) with title "Arcanum CE"' \
            -e 'if r is false then return ""' -e 'return item 1 of r' -e 'end run' "$@" 2>/dev/null)" \
            && { log "  picked: $answer"; printf '%s' "$answer"; return 0; }
    fi
    printf ''
}

found() {  # found PATTERN: matching files in the usual places, one per line
    local dir
    for dir in "$HOME/Downloads" "$HOME/Desktop" "$HERE" "${HERE%/*}"; do
        [ -d "$dir" ] && find "$dir" -maxdepth 1 -type f -iname "$1" 2>/dev/null | sort
    done | awk '!seen[$0]++'
}

locate() {  # locate PATTERN NAME: sets PICKED to the file found or picked; "" if none
    local list count label f
    PICKED=""
    list="$(found "$1")"
    count=0
    [ -n "$list" ] && count="$(printf '%s\n' "$list" | wc -l | tr -d ' ')"
    if [ "$count" -eq 1 ]; then
        PICKED="$list"
        say "  found: $(tilde "$PICKED") ($(size "$PICKED"))"
    elif [ "$count" -gt 1 ]; then
        say "  found $count files that could be $2:"
        printf '%s\n' "$list" | while IFS= read -r f; do say "    $(tilde "$f") ($(size "$f"))"; done
        set --
        while IFS= read -r f; do set -- "$@" "$(tilde "$f") ($(size "$f"))"; done <<EOF
$list
EOF
        label="$(pick "Which one is $2?" "$@")"
        if [ -n "$label" ]; then
            while IFS= read -r f; do
                [ "$(tilde "$f") ($(size "$f"))" = "$label" ] && PICKED="$f"
            done <<EOF
$list
EOF
            say "  chosen: $(tilde "$PICKED")"
        fi
    else
        say "  not in Downloads, on the Desktop or beside this folder."
    fi
}

is_game_folder() {  # is_game_folder DIR: Arcanum.exe and tig.dat at its top, in any case
    local top
    top="$(ls -A "$1" 2>/dev/null)" || return 1
    printf '%s\n' "$top" | grep -qix tig.dat && printf '%s\n' "$top" | grep -qix arcanum.exe
}

choose_game_folder() {  # sets GOG_DIR to a game folder the player chose, or ""
    GOG_DIR=""
    while :; do
        say "  A window opens: choose the game folder (the one holding Arcanum.exe)."
        GOG_DIR="$(choose folder "Choose the Arcanum game folder from a Windows PC (it holds Arcanum.exe)")"
        [ -z "$GOG_DIR" ] && return
        if is_game_folder "$GOG_DIR"; then
            say "  chosen: the game folder $(tilde "$GOG_DIR")"
            return
        fi
        say "  $(tilde "$GOG_DIR") has no Arcanum.exe and tig.dat at its top, so it is not the game folder."
        [ "$(ask "That folder is not Arcanum's game folder: it has no Arcanum.exe and tig.dat. Choose the folder that holds them." "Cancel" "Choose again...")" = "Choose again..." ] || { GOG_DIR=""; return; }
    done
}

# --- 1. the package ------------------------------------------------------------

log "Arcanum CE installer"
say "  package: ${HERE##*/}"
say "  log:     $(tilde "$LOG")"
log "--- started $(date '+%Y-%m-%d %H:%M:%S UTC')"
log "--- this Mac"
{
    sw_vers
    echo "model: $(sysctl -n hw.model 2>/dev/null); machine: $(uname -m); cpu: $(sysctl -n machdep.cpu.brand_string 2>/dev/null)"
    echo "under Rosetta: $(sysctl -n sysctl.proc_translated 2>/dev/null || echo no)"
    echo "memory: $(( $(sysctl -n hw.memsize 2>/dev/null || echo 0) / 1073741824 )) GB"
    df -h "$HOME" | tail -1
    echo "bash $BASH_VERSION"
} 2>&1 | scrub >> "$LOG"
log "--- this package"
{
    ls -lan "$HERE"                          # numeric owners: no account name
    cat "$HERE/tools/SOURCES.txt"; echo
    for tool in gogx 7zz; do
        file "$HERE/tools/$tool"
        codesign -dv "$HERE/tools/$tool" 2>&1 | grep -E '^(Format|Signature|CodeDirectory)'
    done
    # Only whether it is there: its value names the browser and the download time.
    echo "download flag on this installer: $(xattr -p com.apple.quarantine "$0" >/dev/null 2>&1 && echo yes || echo no)"
} 2>&1 | scrub >> "$LOG"

step 1 "checking this package"
if [ "${EUID:-1}" -eq 0 ]; then
    say "  Run the installer as yourself, not as root."
    finish 1
fi
if ! ls "$HOME/Downloads" > /dev/null 2>&1; then
    say "  macOS is not letting Terminal read your Downloads folder. Turn it on in"
    say "  System Settings > Privacy & Security > Files and Folders > Terminal (on macOS 12"
    say "  and earlier: System Preferences > Security & Privacy > Privacy > Files and"
    say "  Folders), then double-click the installer again."
    finish 1
fi
if [ "$(uname -s)" != Darwin ]; then
    say "  This installer is for macOS. On Linux, run setup.sh from this folder."
    finish 1
fi
for f in setup.sh uninstall.sh arcanum-ce-macos.zip tools/gogx tools/7zz; do
    if [ ! -e "$HERE/$f" ]; then
        say "  The package is incomplete: $f is missing."
        say "  Unpack the downloaded arcanum-ce-...-macos.tar.gz again and use the new folder."
        finish 1
    fi
done
# A browser's download flag, passed to every unpacked file, makes Gatekeeper
# refuse the unpackers and the app. Only this package's own files lose it:
# never anything else in the folder the package sits in.
for f in setup.sh uninstall.sh "Uninstall Arcanum CE.command" arcanum-ce-macos.zip tools/gogx tools/7zz; do
    [ -e "$HERE/$f" ] && xattr -d com.apple.quarantine "$HERE/$f" 2>/dev/null
done
if xattr -p com.apple.quarantine "$HERE/tools/gogx" >/dev/null 2>&1; then
    say "  complete, but macOS's download flag stays on its tools; setup says if macOS refuses them."
else
    say "  complete; macOS's download flag cleared from its programs."
fi

# --- 2. GOG's installer ----------------------------------------------------------

step 2 "finding GOG's Arcanum installer (setup_arcanum_....exe)"
GOG=""
GOG_DIR=""
locate 'setup_arcanum*.exe' "GOG's installer"
GOG="$PICKED"
if [ -z "$GOG" ]; then
    choice="$(ask "Arcanum CE needs GOG's offline installer for Arcanum (its name begins setup_arcanum_ and ends .exe), or a game folder installed with it on a Windows PC." \
        "Cancel" "Choose a game folder..." "Choose the installer...")"
    case "$choice" in
        "Choose the installer...")
            say "  A window opens: choose GOG's installer."
            GOG="$(choose file "Choose GOG's Arcanum installer (setup_arcanum_....exe)")"
            [ -n "$GOG" ] && say "  chosen: $(tilde "$GOG") ($(size "$GOG"))" ;;
        "Choose a game folder...")
            choose_game_folder ;;
    esac
fi
if [ -n "$GOG" ]; then
    for bin in "${GOG%.*}"*.bin; do
        if [ -e "$bin" ]; then
            # Known now, not after the questions and an unpack: gogx cannot
            # read an installer that keeps its data in .bin files.
            say "  $(tilde "$bin") lies beside it: an installer with .bin files cannot be unpacked on a Mac."
            choice="$(ask "This GOG download comes with a .bin file, a kind of installer that cannot be unpacked on a Mac.

Install Arcanum with it on a Windows PC, copy the game folder (the one holding Arcanum.exe) to this Mac, and choose it here." \
                "Cancel" "Choose a game folder...")"
            GOG=""
            [ "$choice" = "Choose a game folder..." ] && choose_game_folder
            break
        fi
    done
fi
if [ -n "$GOG" ]; then
    kb="$(du -k "$GOG" | awk '{print $1}')"
    if [ "${kb:-0}" -lt 1048576 ]; then
        say "  note: this file is only $((kb / 1024)) MB, and GOG's installer is about 1.2 GB."
        say "  If its download has not finished, wait for it; setup checks the file either way."
    fi
fi
if [ -z "$GOG$GOG_DIR" ]; then
    say "  Nothing chosen. Download the installer from your GOG library (Arcanum,"
    say "  'offline backup game installers', Windows) into Downloads and start again."
    finish 1
fi

# --- 3. UAP ------------------------------------------------------------------------

step 3 "finding the Unofficial Arcanum Patch (UAP2.0.2.exe)"
locate 'UAP*2.0.2*.exe' "the patch"
UAP="$PICKED"
if [ -z "$UAP" ]; then
    say "  A window opens: choose UAP2.0.2.exe."
    UAP="$(choose file "Choose the Unofficial Arcanum Patch, UAP2.0.2.exe")"
    if [ -z "$UAP" ]; then
        say "  Nothing chosen. The patch comes from terra-arcanum.com (search for"
        say "  'Unofficial Arcanum Patch'); put UAP2.0.2.exe in Downloads and start again."
        finish 1
    fi
    say "  chosen: $(tilde "$UAP") ($(size "$UAP"))"
fi

# --- 4. where, and room ----------------------------------------------------------------

step 4 "choosing the game folder"
OLD_SAVES=""
DEST="$HOME/Games/arcanum-ce"
n=1
while [ -e "$DEST" ]; do
    listing="$(ls -A "$DEST" 2>/dev/null)" || listing="(unreadable)"
    [ -z "$listing" ] && break
    # Every existing folder is left alone; what it holds decides what is said.
    if [ -f "$DEST/.arcanum-ce-install" ] && [ -d "$DEST/.setup-work" ]; then
        say "  $(tilde "$DEST") holds an install that is running or was stopped; it is left alone."
    elif [ -f "$DEST/.arcanum-ce-install" ]; then
        say "  $(tilde "$DEST") already holds Arcanum CE."
        if [ "$n" -eq 1 ]; then
            choice="$(ask "Arcanum CE is already installed in $(tilde "$DEST")." "Cancel" "Install another copy" "Start it")"
            case "$choice" in
                "Start it")
                    # The app setup recorded, not any .app someone put beside it.
                    app="$(grep -m1 '\.app$' "$DEST/.arcanum-ce-install" | grep -v /)"
                    if [ -n "$app" ] && [ -d "$DEST/$app" ] && open "$DEST/$app"; then
                        say "  Starting it; nothing else was changed."
                    else
                        say "  macOS did not open it. Open ${app:-the app} from Finder in $(tilde "$DEST")."
                        open "$DEST" 2>/dev/null
                    fi
                    finish 0 ;;
                "Install another copy") say "  installing another copy beside it." ;;
                *) say "  Nothing was changed."; finish 0 ;;
            esac
        fi
        if [ -z "$OLD_SAVES" ] && [ -n "$(find "$DEST/modules/Arcanum/SaveCE" -type f 2>/dev/null | head -1)" ]; then
            say "  Its saves can be copied into the new install at the end."
            OLD_SAVES="$DEST/modules/Arcanum/SaveCE"
        fi
    elif [ -n "$(find "$DEST/modules/Arcanum/SaveCE" -type f 2>/dev/null | head -1)" ]; then
        say "  $(tilde "$DEST") holds saves from an earlier Arcanum CE; it is left alone,"
        say "  and you can copy those saves into the new install at the end."
        [ -z "$OLD_SAVES" ] && OLD_SAVES="$DEST/modules/Arcanum/SaveCE"
    else
        say "  $(tilde "$DEST") holds files this installer did not finish or did not make;"
        say "  it is left alone. (Look inside before deleting it: it may be yours.)"
    fi
    n=$((n + 1))
    DEST="$HOME/Games/arcanum-ce-$n"
done
say "  the game folder will be $(tilde "$DEST")"
mkdir -p "$HOME/Games"
free_kb="$(df -k "$HOME/Games" | awk 'NR == 2 {print $4}')"
say "  free space: $((free_kb / 1048576)) GB"
if [ "${free_kb:-0}" -lt $((3 * 1048576)) ]; then
    # Not a refusal: macOS frees purgeable space (snapshots, caches) when it
    # is needed, and df does not count it; setup names a full disk if it hits one.
    choice="$(ask "Only $((free_kb / 1048576)) GB is free, and setup needs about 3 GB. macOS can sometimes free more when it is needed." "Cancel" "Continue anyway")"
    if [ "$choice" != "Continue anyway" ]; then
        say "  Nothing was changed. Make room on the disk and start again."
        finish 1
    fi
fi

# --- 5. mods, and the go-ahead ----------------------------------------------------------

step 5 "choosing the optional mods"
MOD_ARGS=()
MOD_NAMES=""
CONFIRMED=0
chosen="CANCELLED"
dialog_rc=1
if have_dialogs && [ -f "$HERE/mods.txt" ]; then
    # The dialog lists names only; what each does is here, in the window.
    say "  The optional mods (all off unless you choose them):"
    set --
    while IFS="$(printf '\t')" read -r id name what _; do
        case "$id" in ''|\#*) continue ;; esac
        say "    $name: $what"
        set -- "$@" "$name"
    done < "$HERE/mods.txt"
    printf '  A dialog asks which optional mods to turn on.\n'
    chosen="$(osascript -e 'on run argv' -e 'activate' \
        -e 'set r to choose from list (items 2 thru -1 of argv) with prompt (item 1 of argv) with title "Arcanum CE" OK button name "Next" with multiple selections allowed and empty selection allowed' \
        -e 'if r is false then return "CANCELLED"' \
        -e "set AppleScript's text item delimiters to linefeed" -e 'return r as text' -e 'end run' \
        "Turn on any optional mods (Cmd-click for several). With none chosen you get the game as it was, only fixed. Each can be turned on or off later in arcanum-ce.cfg; the Terminal window and the README say what each does." \
        "$@" 2>/dev/null)"
    dialog_rc=$?
    log "  mods dialog: exit $dialog_rc, chose: $(printf '%s' "$chosen" | tr '\n' ',')"
fi
if [ "$dialog_rc" -eq 0 ]; then
    if [ "$chosen" = CANCELLED ]; then
        say "  Nothing was changed."
        finish 0
    fi
    while IFS="$(printf '\t')" read -r id name _; do
        case "$id" in ''|\#*) continue ;; esac
        if printf '%s\n' "$chosen" | grep -qxF "$name"; then
            MOD_ARGS+=(--mod "$id")
            MOD_NAMES="$MOD_NAMES, $name"
        fi
    done < "$HERE/mods.txt"
    MOD_NAMES="${MOD_NAMES#, }"
    say "  mods on: ${MOD_NAMES:-none}"
    choice="$(ask "Install Arcanum CE into $(tilde "$DEST") now?

Optional mods on: ${MOD_NAMES:-none}
It takes a few minutes." "Cancel" "Install")"
    if [ "$choice" != Install ]; then
        say "  Nothing was changed."
        finish 0
    fi
    CONFIRMED=1
else
    # No osascript, or it could not show the dialog: setup asks instead.
    have_dialogs && say "  (macOS did not show the dialog; setup asks in this window instead.)"
    say "  setup asks about each mod in this window: type y and Return for yes, Return alone for no."
fi

# --- 6. setup --------------------------------------------------------------------------

step 6 "running setup"
if [ -n "$GOG_DIR" ]; then
    log "  the same as: ARCANUM_SETUP_GOG_DIR=\"$GOG_DIR\" bash setup.sh --uap \"$UAP\" --dir \"$DEST\" ${MOD_ARGS[*]:-}"
else
    log "  the same as: bash setup.sh --gog \"$GOG\" --uap \"$UAP\" --dir \"$DEST\" ${MOD_ARGS[*]:-}"
fi
say "  Setup works through five parts of its own, 1/5 to 5/5, saying what it does;"
say "  it takes a few minutes. Ctrl-C stops it."
[ "$CONFIRMED" -eq 1 ] || say "  It first asks to continue: type y and press Return."
say ""
log "--- setup.sh"
SETUP_ARGS=(--uap "$UAP" --dir "$DEST")
[ -n "$GOG" ] && SETUP_ARGS+=(--gog "$GOG")
[ "$CONFIRMED" -eq 1 ] && SETUP_ARGS+=(--yes "${MOD_ARGS[@]+"${MOD_ARGS[@]}"}")
# Ctrl-C stops setup, which cleans up after itself; this installer then says
# so. tee -i keeps the copy of setup's output going to the end.
trap ':' INT
set -o pipefail
ARCANUM_SETUP_UI=installer ARCANUM_SETUP_GOG_DIR="$GOG_DIR" \
    bash "$HERE/setup.sh" "${SETUP_ARGS[@]}" 2>&1 | tee -i "$OUT"
rc=$?
set +o pipefail
trap 'say ""; say "Stopped with Ctrl-C."; finish 130' INT
keep_output
log "--- setup.sh exit $rc"
if [ "$rc" -eq 130 ]; then
    say "Setup was stopped with Ctrl-C; its last lines above say what became of the folder."
    finish 130
fi
if [ "$rc" -ne 0 ]; then
    if grep -q "Nothing was changed." "$LOG"; then
        say "You chose not to continue, so nothing was installed."
        finish 0
    fi
    finish "$rc"
fi

APP="$(find "$DEST" -maxdepth 1 -name '*.app' -type d | head -1)"
say ""
say "Arcanum CE is installed in $(tilde "$DEST")."
if [ -n "$OLD_SAVES" ] && [ -n "$APP" ]; then
    saves="$(find "$OLD_SAVES" -type f | wc -l | tr -d ' ')"
    choice="$(ask "Copy the saves in $(tilde "$OLD_SAVES") ($saves files) into the new install? They are copied: the old ones stay where they are." "Not now" "Copy them")"
    if [ "$choice" = "Copy them" ]; then
        mkdir -p "$DEST/modules/Arcanum/SaveCE"
        if cp -R "$OLD_SAVES/." "$DEST/modules/Arcanum/SaveCE/"; then
            say "Copied the saves ($saves files) from $(tilde "$OLD_SAVES")."
        else
            say "Copying the saves did not finish; the old ones are untouched in $(tilde "$OLD_SAVES")."
        fi
    fi
fi
if [ -n "$APP" ]; then
    if grep -q "macOS did not let the app run yet" "$LOG"; then
        # Setup has said what to do; Finder shows the app for it.
        open -R "$APP" 2>/dev/null
        finish 0
    fi
    choice="$(ask "Arcanum CE is installed. Start it now?" "Later" "Start Arcanum CE")"
    if [ "$choice" = "Start Arcanum CE" ]; then
        say "Starting Arcanum CE..."
        if ! open "$APP"; then
            say "macOS did not open it. Open it from Finder; if macOS refuses, see the guide's"
            say "'Start the game the first time' (Open Anyway)."
            open -R "$APP" 2>/dev/null
        fi
    else
        open -R "$APP" 2>/dev/null
    fi
    say "To start it later, open ${APP##*/} in $(tilde "$DEST")."
    say "You can drag it to the Dock; the app itself must stay in the game folder."
    say "To remove it later, double-click Uninstall Arcanum CE in the same folder."
fi
finish 0
