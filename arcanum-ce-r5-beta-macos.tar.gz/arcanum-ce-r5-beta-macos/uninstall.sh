#!/usr/bin/env bash
# Arcanum CE - remove what setup.sh installed (release 1, R7).
#
#   ./arcanum-ce-uninstall.sh [--all] [--yes]
#
# Without --all it removes Arcanum CE itself - the program, its settings,
# the optional mods and the menu entry - and leaves the game files and the
# saves (modules/Arcanum/SaveCE). With --all it deletes the whole game folder
# setup.sh made, saves included, after asking.
set -euo pipefail

# The real folder, not a link to it, so --all deletes what it says it does.
DEST="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ALL=0
ASSUME_YES=0
while [ $# -gt 0 ]; do
    case "$1" in
        --all) ALL=1; shift ;;
        --yes|-y) ASSUME_YES=1; shift ;;
        -h|--help) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "uninstall: unknown argument: $1" >&2; exit 1 ;;
    esac
done

[ "${EUID:-1}" -ne 0 ] || { echo "uninstall: run this as yourself, not as root or with sudo" >&2; exit 1; }
MANIFEST="$DEST/.arcanum-ce-install"
[ -f "$MANIFEST" ] || { echo "uninstall: $DEST was not set up by Arcanum CE's setup.sh" >&2; exit 1; }

confirm() {
    [ "$ASSUME_YES" -eq 1 ] && return 0
    printf '%s [y/N] ' "$1"
    read -r answer || answer=""
    case "$answer" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

count() { find "$1" -type f 2>/dev/null | wc -l | tr -d ' '; }

if [ "$ALL" -eq 1 ]; then
    echo "This deletes the whole folder $DEST and everything in it, for good:"
    echo "  the game files and Arcanum CE"
    [ -d "$DEST/modules/Arcanum/SaveCE" ] && echo "  your Arcanum CE saves: $(count "$DEST/modules/Arcanum/SaveCE") files in modules/Arcanum/SaveCE"
    [ -d "$DEST/modules/Arcanum/Save" ] && echo "  the original game's saves: $(count "$DEST/modules/Arcanum/Save") files in modules/Arcanum/Save"
    echo "  and anything else you put there."
    confirm "Delete it?" || { echo "Nothing was removed."; exit 1; }
fi

# Only names setup.sh writes, and never through a link: a damaged or edited
# manifest must not reach the player's own files (review 2026-10-31).
while IFS= read -r entry; do
    case "$entry" in
        desktop:*)
            path="${entry#desktop:}"
            case "$path" in
                # One name serves every install: remove it only while it
                # still names this folder, not a newer install's (review
                # 2026-10-31, finding 13).
                */applications/arcanum-ce.desktop)
                    [ -L "$path" ] || ! grep -qxF "Path=$DEST" "$path" 2>/dev/null || rm -f "$path" ;;
            esac ;;
        *.app|arcanum-ce|arcanum-ce-uninstall.sh|arcanum-ce-*.md|ce-mods|arcanum-ce.cfg|"Uninstall Arcanum CE.command")
            case "$entry" in */*) continue ;; esac
            [ -L "$DEST/$entry" ] && continue
            rm -rf "${DEST:?}/$entry" ;;
    esac
done < "$MANIFEST"
rm -f "$MANIFEST"
rm -f "$DEST/arcanum-ce.log"   # written by the game, not setup; not a save

if [ "$ALL" -eq 1 ]; then
    rm -rf "${DEST:?}"
    echo "Removed $DEST."
else
    echo "Arcanum CE is removed. The game files and your saves remain in $DEST."
    if [ "$(uname -s)" = Darwin ]; then
        echo "To install Arcanum CE again, double-click its installer: it installs into a"
        echo "new folder beside this one and offers to copy these saves into it."
    else
        echo "To install Arcanum CE again, run setup.sh with --dir and a new folder, then"
        echo "copy modules/Arcanum/SaveCE from here into it to keep these saves."
    fi
fi
