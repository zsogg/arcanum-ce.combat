#!/usr/bin/env bash
# Arcanum CE - native Linux and macOS setup (release 1, R7; macOS, release 2).
#
# Builds a game folder from the two Windows installers, with native tools and
# no Wine: GOG's offline installer for Arcanum 1.0.7.4 (unpacked by
# innoextract) and the Unofficial Arcanum Patch, UAP2.0.2.exe (unpacked by
# 7z). It lays down UAP's reference component set and the High Resolution
# Patch's files exactly as UAP's own installer and the patch's install script
# would, then installs Arcanum CE beside them with the release configuration.
#
#   ./setup.sh --gog setup_arcanum_*.exe --uap UAP2.0.2.exe [--dir DIR]
#              [--all-mods | --mod ID ...] [--no-desktop] [--yes]
#
# Setup asks about each optional mod in turn (release/mods.txt's questions),
# every answer defaulting to no. --all-mods or --mod ID (repeatable) answer in
# advance; with --yes and neither, all stay off. A mod can be turned on or off
# later with its line in arcanum-ce.cfg.
#
# DIR defaults to ~/Games/arcanum-ce and must be new or empty. Nothing outside
# DIR is written except the menu entry (~/.local/share/applications), which
# --no-desktop skips. uninstall.sh, copied into DIR, removes what this added.
#
# On macOS (release 2, untested on a Mac) the same steps run with macOS's
# shasum and the package's own unpackers in tools/ (MAC2): gogx for GOG's
# installer and 7-Zip's 7zz for UAP's, so no package manager is needed. A
# tools/ folder is used before anything on PATH, on any system. Step 4
# unpacks the app from arcanum-ce-macos.zip beside the game files instead of
# the binary. There is no menu entry; the app lives in DIR. The script keeps
# to bash 3.2, the /bin/bash macOS ships.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MACOS=0; [ "$(uname -s)" = Darwin ] && MACOS=1
GOG=""
UAP=""
DEST="${HOME}/Games/arcanum-ce"
DESKTOP=1
ASSUME_YES=0
ALL_MODS=0
WANTED_MODS=""

usage() { sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'; }
die() { printf 'setup: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

while [ $# -gt 0 ]; do
    case "$1" in
        --gog) GOG="$2"; shift 2 ;;
        --uap) UAP="$2"; shift 2 ;;
        --dir) DEST="$2"; shift 2 ;;
        --no-desktop) DESKTOP=0; shift ;;
        --all-mods) ALL_MODS=1; shift ;;
        --mod) WANTED_MODS="$WANTED_MODS $2"; shift 2 ;;
        --yes|-y) ASSUME_YES=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown argument: $1 (see --help)" ;;
    esac
done

# --- what is needed ---------------------------------------------------------

# As root the game folder would belong to root: the game could not write its
# saves, and every delete below would lose the permission checks that stop a
# mistake (review 2026-10-31).
[ "${EUID:-1}" -ne 0 ] || die "run setup as yourself, not as root or with sudo"
# Run by the macOS double-click installer: shorter endings, advice that fits
# a player who typed nothing.
UI="${ARCANUM_SETUP_UI:-}"
[ -n "$UAP" ] || die "--uap UAP2.0.2.exe is required"
[ -f "$UAP" ] || die "no such file: $UAP"
# A game folder installed by GOG's installer (on a Windows PC, say) in place
# of the installer itself: the route for an installer gogx cannot read.
GOG_DIR="${ARCANUM_SETUP_GOG_DIR:-}"
if [ -z "$GOG_DIR" ]; then
    [ -n "$GOG" ] || die "--gog setup_arcanum_*.exe is required (GOG's offline installer)"
    [ -f "$GOG" ] || die "no such file: $GOG"
else
    # Checked before it is copied: a wrong pick (Downloads, the home folder)
    # would otherwise be copied whole, and links inside it would let later
    # steps write through them into the player's other files.
    [ -d "$GOG_DIR" ] || die "no such folder: $GOG_DIR"
    GOG_DIR="$(cd "$GOG_DIR" && pwd -P)" || die "cannot open $GOG_DIR"
    top="$(ls -A "$GOG_DIR")" || die "cannot read $GOG_DIR"
    if ! printf '%s\n' "$top" | grep -qix tig.dat || ! printf '%s\n' "$top" | grep -qix arcanum.exe; then
        die "$GOG_DIR is not Arcanum's game folder: choose the folder that holds Arcanum.exe and tig.dat"
    fi
    if [ -n "$(find "$GOG_DIR" -type l | head -1)" ]; then
        die "$GOG_DIR holds symbolic links: copy the game folder itself, without links"
    fi
fi
if [ "$MACOS" -eq 1 ]; then PAYLOAD=arcanum-ce-macos.zip; DESKTOP=0; else PAYLOAD=arcanum-ce; fi
for f in "$PAYLOAD" arcanum-ce.base.cfg mods.txt uap-2.0.2-reference.sha256 gog-1.0.7.4.sha256 uninstall.sh; do
    [ -e "$HERE/$f" ] || die "the package is incomplete: $f is missing beside setup.sh"
done

case "$DEST" in /*) ;; *) DEST="$PWD/$DEST" ;; esac
if [ -e "$DEST" ]; then
    # The real folder behind a link, so the cleanup and the uninstaller act on
    # it; and a folder that cannot be listed is not taken for an empty one.
    [ -d "$DEST" ] || die "$DEST exists and is not a folder"
    DEST="$(cd "$DEST" && pwd -P)" || die "cannot open $DEST"
    listing="$(ls -A "$DEST")" || die "cannot read $DEST (if macOS asked whether Terminal may use it, allow it and run setup again)"
    [ -z "$listing" ] || die "$DEST already has files in it; choose a new folder with --dir"
fi
if [ -n "$GOG_DIR" ]; then
    case "$DEST/" in "$GOG_DIR"/*) die "the game folder cannot be inside $GOG_DIR, the folder being copied" ;; esac
fi

missing=""
# The macOS package carries its unpackers in tools/. A browser download
# passes macOS's quarantine flag to every file unpacked from it, and
# Gatekeeper refuses a flagged program that is not notarized, so the flag is
# cleared first, as step 4 does for the app.
TOOLS="$HERE/tools"
if [ "$MACOS" -eq 1 ] && [ -d "$TOOLS" ]; then
    xattr -d com.apple.quarantine "$TOOLS/gogx" 2>/dev/null || true
    xattr -d com.apple.quarantine "$TOOLS/7zz" 2>/dev/null || true
fi
GOGX=""
if [ -z "$GOG_DIR" ]; then
    if [ -x "$TOOLS/gogx" ]; then GOGX="$TOOLS/gogx"
    else command -v innoextract >/dev/null || missing="$missing innoextract"; fi
fi
if [ -x "$TOOLS/7zz" ]; then SEVENZ="$TOOLS/7zz"
else
    SEVENZ=7z
    command -v 7z >/dev/null || { command -v 7zz >/dev/null && SEVENZ=7zz; } || missing="$missing 7z"
fi
if command -v sha256sum >/dev/null; then sha256() { sha256sum | cut -d' ' -f1; }
elif command -v shasum >/dev/null; then sha256() { shasum -a 256 | cut -d' ' -f1; }
else missing="$missing sha256sum"; fi
if [ -n "$missing" ]; then
    say "setup needs:$missing"
    if [ "$MACOS" -eq 1 ]; then
        say "  The package's tools folder ($TOOLS) is missing or incomplete."
        say "  Unpack the downloaded arcanum-ce-*-macos.tar.gz again and run setup.sh"
        say "  from the new folder."
        exit 1
    fi
    say "  Debian/Ubuntu: sudo apt install innoextract p7zip-full"
    say "  Fedora:        sudo dnf install innoextract p7zip p7zip-plugins"
    say "  Arch:          sudo pacman -S innoextract 7zip"
    exit 1
fi


say "Arcanum CE setup"
say "  GOG installer: ${GOG_DIR:-$GOG}"
say "  UAP installer: $UAP"
say "  game folder:   $DEST"
if [ -n "$GOG_DIR" ]; then gog_tool="none (a game folder)"; else gog_tool="${GOGX:-innoextract}"; fi
say "  unpackers:     $gog_tool; $SEVENZ"
if [ "$ASSUME_YES" -eq 0 ]; then
    printf 'Continue? [y/N] '
    read -r answer
    case "$answer" in y|Y|yes|YES) ;; *) say "Nothing was changed."; exit 1 ;; esac
fi

# --- the optional mods: asked now, applied with the settings in step 4 -------

MOD_IDS=""
MOD_NAME=(); MOD_ABOUT=(); MOD_ID=(); MOD_QUESTION=()
while IFS=$'\t' read -r id name about question; do
    case "$id" in ''|\#*) continue ;; esac
    MOD_ID+=("$id"); MOD_NAME+=("$name"); MOD_ABOUT+=("$about"); MOD_QUESTION+=("$question")
    MOD_IDS="$MOD_IDS $id"
done < "$HERE/mods.txt"
for id in $WANTED_MODS; do
    case " $MOD_IDS " in *" $id "*) ;; *) die "no optional mod called $id (there are:$MOD_IDS)" ;; esac
done
ask() {  # ask QUESTION -> 0 for yes; no is the default
    local answer
    printf '%s [y/N] ' "$1"
    read -r answer || answer=""
    case "$answer" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}
ON_MODS=""
if [ "$ALL_MODS" -eq 1 ]; then
    ON_MODS="$MOD_IDS"
elif [ -n "$WANTED_MODS" ]; then
    ON_MODS="$WANTED_MODS"
elif [ "$ASSUME_YES" -eq 0 ]; then
    say ""
    say "Arcanum CE comes with ${#MOD_ID[@]} optional mods, each off unless you turn it on:"
    for i in "${!MOD_ID[@]}"; do
        say ""
        say "  ${MOD_NAME[i]}: ${MOD_ABOUT[i]}."
        if ask "${MOD_QUESTION[i]}"; then ON_MODS="$ON_MODS ${MOD_ID[i]}"; fi
    done
fi
say "  optional mods on:${ON_MODS:- none}"

mkdir -p "$DEST"
DEST="$(cd "$DEST" && pwd -P)"
if [ -n "$GOG_DIR" ]; then
    # Again on the real path: a link on the way may lead inside after all.
    case "$DEST/" in "$GOG_DIR"/*) rmdir "$DEST" 2>/dev/null; die "the game folder cannot be inside $GOG_DIR, the folder being copied" ;; esac
fi
WORK="$DEST/.setup-work"
# The work folder is also a lock: a second setup into the same folder, started
# while this one waited at its questions, must stop here, before this one's
# cleanup could empty the other's finished install (review 2026-10-31).
if ! mkdir "$WORK" 2>/dev/null; then
    die "another setup is using $DEST; if none is running, remove $WORK and start again"
fi
if [ "$(ls -A "$DEST")" != ".setup-work" ]; then
    rmdir "$WORK"
    die "$DEST is no longer empty; choose a new folder with --dir"
fi
# A failure after the GOG copy used to leave a gigabyte behind that a second
# run then refused ("already has files in it") and nothing could remove, the
# uninstaller not being installed yet. DEST was empty or new when this
# started, so until the uninstaller is in place (step 4), a failed run
# empties it again (review 2026-10-22, finding 15). After that the copy is
# whole and the uninstaller can remove it, so a failure in the check keeps
# the folder: on a Mac, step 5 is the first time the app runs, and a
# Gatekeeper refusal there must not delete the app the player has to clear.
DONE=0
KEEP=0
UNPACK_PID=""
cleanup() {
    # Ctrl-C or a closed Terminal window ends setup here too. Stop a running
    # unpacker first (a background job ignores Ctrl-C) and delete before
    # printing: with the window gone, the output pipe is dead, and a write
    # into it must not end the cleanup half-way.
    set +e
    trap '' PIPE
    if [ -n "$UNPACK_PID" ]; then
        kill "$UNPACK_PID" 2>/dev/null
        wait "$UNPACK_PID" 2>/dev/null
    fi
    rm -rf "$WORK"
    if [ "$DONE" != 1 ]; then
        printf '\n'
        if [ "$KEEP" = 1 ]; then
            say "setup did not finish; $DEST is kept. Remove it with \"$DEST/arcanum-ce-uninstall.sh --all\", or fix the cause and start the game from it."
        else
            find "$DEST" -mindepth 1 -delete 2>/dev/null
            say "setup did not finish; the partial copy in $DEST was removed."
        fi
    fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 129' HUP
trap 'exit 143' TERM

# --- placing files without regard to case -------------------------------------
#
# Windows merges `Modules` and `modules`; Linux would keep both, and the
# engine would see whichever it resolved first. Every placement below follows
# an existing spelling of each path component, whatever its case.

match_child() {  # match_child DIR NAME -> the existing entry spelt NAME in any case
    local dir="$1" name="$2" entry
    for entry in "$dir"/* "$dir"/.[!.]*; do
        [ -e "$entry" ] || continue
        if [ "${entry##*/}" = "$name" ] || [ "$(printf '%s' "${entry##*/}" | tr 'A-Z' 'a-z')" = "$(printf '%s' "$name" | tr 'A-Z' 'a-z')" ]; then
            printf '%s' "$entry"
            return 0
        fi
    done
    return 1
}

resolve() {  # resolve REL -> a path under DEST, creating directories as needed
    local rel="$1" path="$DEST" found i last
    local -a parts
    IFS='/' read -r -a parts <<< "$rel"
    last=$(( ${#parts[@]} - 1 ))
    for (( i = 0; i < last; i++ )); do
        if found="$(match_child "$path" "${parts[i]}")"; then path="$found"
        else path="$path/${parts[i]}"; mkdir -p "$path"; fi
    done
    if found="$(match_child "$path" "${parts[last]}")"; then printf '%s' "$found"
    else printf '%s' "$path/${parts[last]}"; fi
}

place() {  # place SRC REL: copy one file into DEST at REL, case-merged
    local target
    target="$(resolve "$2")"
    cp -f "$1" "$target"
}

place_tree() {  # place_tree SRC_DIR REL_DIR: every file under SRC_DIR
    local src="$1" rel="$2" file
    while IFS= read -r -d '' file; do
        place "$file" "$rel/${file#"$src"/}"
    done < <(find "$src" -type f -print0)
}

unpack() {  # unpack WHAT ADVICE LOG TOOL ARGS...: run an unpacker; on failure show why
    local what="$1" advice="$2" log="$3" rc=0 start="$SECONDS" ticks=0 pid
    shift 3
    # The unpackers are quiet for half a minute or more: a dot every five
    # seconds shows setup is working, not stuck.
    "$@" > "$log" 2>&1 &
    pid=$!
    UNPACK_PID="$pid"
    printf '  working'
    while kill -0 "$pid" 2>/dev/null; do
        sleep 1
        ticks=$((ticks + 1))
        [ $((ticks % 5)) -eq 0 ] && printf '.'
    done
    wait "$pid" || rc=$?
    UNPACK_PID=""
    if [ "$rc" -eq 0 ]; then
        printf ' done (%d s)\n' $((SECONDS - start))
        return 0
    fi
    printf ' failed after %d s\n' $((SECONDS - start))
    sed 's/^/  /' "$log"
    if grep -qi "no space left" "$log"; then
        die "the disk is full: free about 3 GB and start again"
    fi
    # 126: the program could not be executed; 137: killed, which is how
    # macOS stops a program whose signature or quarantine it refuses.
    if [ "$MACOS" -eq 1 ] && { [ "$rc" -eq 126 ] || [ "$rc" -eq 137 ]; }; then
        if [ "$UI" = installer ]; then
            say "  macOS would not run ${1##*/}, one of this package's tools. Please tell us"
            say "  (the README's 'Reporting a problem'), with the installer's log."
        else
            say "  macOS did not let ${1##*/} run (exit $rc). Clear the flag macOS puts on"
            say "  downloads from this package's tools, and run setup again:"
            say "    xattr -d com.apple.quarantine \"$TOOLS/gogx\" \"$TOOLS/7zz\""
        fi
        die "macOS refused to run $1"
    fi
    say "  $advice"
    die "$what (exit $rc; the reason is above)"
}

# --- 1. the base game, from GOG's installer ------------------------------------

if [ -n "$GOG_DIR" ]; then
    say "1/5 the base game, from $GOG_DIR..."
    GOG_ROOT="$GOG_DIR"
elif [ -n "$GOGX" ]; then
    say "1/5 unpacking the base game..."
    # gogx writes innoextract's --exclude-temp layout and checks every file.
    unpack "gogx could not unpack $GOG" \
        "GOG's installer may be damaged or a different version: download it again from your GOG library (Arcanum, offline backup game installers, Windows)." \
        "$WORK/gogx.log" "$GOGX" "$GOG" "$WORK/gog"
    say "  $(tail -1 "$WORK/gogx.log")"
else
    say "1/5 unpacking the base game..."
    unpack "innoextract could not unpack $GOG" \
        "GOG's installer may be damaged or a different version: download it again from your GOG library (Arcanum, offline backup game installers, Windows)." \
        "$WORK/innoextract.log" innoextract --silent --progress=0 --exclude-temp -d "$WORK/gog" "$GOG"
fi
if [ -z "$GOG_DIR" ]; then
    tig="$(find "$WORK/gog" -maxdepth 3 -iname tig.dat -type f | head -1)"
    [ -n "$tig" ] || die "$GOG does not look like Arcanum's GOG installer (no tig.dat inside)"
    GOG_ROOT="$(dirname "$tig")"
fi
if [ -n "$GOG_DIR" ]; then
    say "  copying the game folder into $DEST..."
    # A gigabyte from a slow disk or a USB stick: the same dots as an unpack.
    unpack "could not copy $GOG_ROOT into $DEST" \
        "Check that the game folder can be read, and that the disk has about 3 GB free." \
        "$WORK/copy.log" cp -a "$GOG_ROOT"/. "$DEST"/
else
    # Moved, not copied: the unpacked files are on the same disk already, so
    # this is instant and needs no second 1.3 GB.
    say "  moving the game files into $DEST..."
    for entry in "$GOG_ROOT"/* "$GOG_ROOT"/.[!.]*; do
        [ -e "$entry" ] || continue
        mv "$entry" "$DEST"/ || die "could not move $entry into $DEST"
    done
fi
# GOG's own installer machinery, not the game. Measured on GOG's 1.0.7.4
# "ddrawfix" build (77721), whose game files sit at the top: `__redist`,
# `commonappdata` and an `app` folder holding only an icon and a web cache.
rm -rf "$DEST/__redist" "$DEST/__support" "$DEST/commonappdata" "$DEST/tmp" 2>/dev/null || true
if [ -d "$DEST/app" ] && [ -z "$(find "$DEST/app" -iname tig.dat | head -1)" ]; then
    rm -rf "$DEST/app"
fi

say "  checking them against GOG 1.0.7.4's hashes..."
gog_mismatch=0
while read -r sum rel; do
    case "$sum" in ''|\#*) continue ;; esac
    file="$(resolve "$rel")"
    if [ ! -f "$file" ]; then
        die "the base game is missing $rel - is this Arcanum's GOG installer?"
    fi
    if [ "$(sha256 < "$file")" != "$sum" ]; then
        gog_mismatch=1
        say "  note: $rel differs from GOG 1.0.7.4 as this release was tested with (setup goes on)"
    fi
done < "$HERE/gog-1.0.7.4.sha256"
[ "$gog_mismatch" -eq 0 ] && say "  Arcanum 1.0.7.4 found (its files are the same from GOG and Steam)"

# --- 2. UAP's reference component set ------------------------------------------

say "2/5 unpacking the Unofficial Arcanum Patch..."
# The one UAP 2.0.2 release, as terra-arcanum.com links it. A different file
# is not refused here, since each file taken from it is checked below.
if [ "$(sha256 < "$UAP")" = 8cc3e89859a0d669910483622741180c1f60a605bbb924f65c60df18ddd8dc1c ]; then
    say "  UAP2.0.2.exe is the release this was tested with"
else
    say "  note: this UAP2.0.2.exe is not the one this release was tested with; each file taken from it is checked"
fi
# -tNsis: only 7-Zip's reader for NSIS installers, whatever the file holds.
unpack "7-Zip could not unpack $UAP" \
    "UAP2.0.2.exe may be damaged: download it again (terra-arcanum.com, 'Unofficial Arcanum Patch')." \
    "$WORK/7z.log" "$SEVENZ" x -tNsis -y -bd -o"$WORK/uap" "$UAP"
say "  checking and placing its files..."
while read -r sum rel; do
    case "$sum" in ''|\#*) continue ;; esac
    src="$WORK/uap/$rel"
    [ -f "$src" ] || die "$UAP has no $rel - this release needs UAP 2.0.2"
    if [ "$(sha256 < "$src")" != "$sum" ]; then
        die "$rel inside $UAP is not UAP 2.0.2's - this release needs UAP 2.0.2"
    fi
    place "$src" "$rel"
done < "$HERE/uap-2.0.2-reference.sha256"
# UAP's installer runs Sierra's RemoveProtos.exe: loose prototypes left by an
# earlier version hide the archives' (now UAP's) copies. A fresh folder has
# none; step 5's check reports any that appear.
say "  UAP 2.0.2 is in place: its data, animations, sounds, races, Pyro Bow and Virgil fix"

# --- 3. the High Resolution Patch, as HighRes.tp2 installs it ----------------

say "3/5 the High Resolution Patch..."
HRP="$WORK/uap/HighRes/Files"
CONFIG="$(resolve HighRes/config.ini)"
[ -f "$CONFIG" ] || die "UAP's HighRes/config.ini was not laid down"
setting() {  # setting KEY -> its integer value in HighRes/config.ini
    tr -d '\r' < "$CONFIG" | sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*\([0-9]*\).*/\1/p" | head -1
}
WIDTH="$(setting Width)"; BORDERS="$(setting Borders)"; MENU_ART="$(setting MainMenuArt)"
[ -n "$WIDTH" ] || die "HighRes/config.ini has no Width"

# _install.bat clears the modules' map folders (their top-level files) first.
for module in Arcanum Vormantown; do
    maps="$(resolve "modules/$module/maps/.keep")"; maps="${maps%/.keep}"
    find "$maps" -maxdepth 1 -type f -delete
done
# Sound positioning scaled to the screen width.
sound="$(resolve data/sound/soundparams.mes)"
sed -e "s/{1}{50}/{1}{$((WIDTH / 16))}/" -e "s/{2}{800}/{2}{$WIDTH}/" \
    -e "s/{3}{100}/{3}{$((WIDTH / 8))}/" -e "s/{4}{400}/{4}{$((WIDTH / 2))}/" \
    "$HRP/soundparams.mes" > "$sound"
# The shop map (the main menu's backdrop) and the half-ogre captain fix.
place_tree "$HRP/maps/ShopMap" modules/Arcanum/maps/ShopMap
place_tree "$HRP/maps/ShopMap" modules/Vormantown/maps/ShopMap
place_tree "$HRP/maps/Arcanum1-024-fixed" modules/Arcanum/maps/Arcanum1-024-fixed
if [ "${MENU_ART:-0}" = 2 ]; then
    place "$HRP/maps/0_dirt.sec" modules/Arcanum/maps/ShopMap/0.sec
    place "$HRP/maps/0_dirt.sec" modules/Vormantown/maps/ShopMap/0.sec
fi
place "$HRP/ArcanumZHighRes.dat" ArcanumZHighRes.dat
if [ "${BORDERS:-0}" = 1 ]; then
    place "$HRP/ArcanumZHighResBorders.dat" ArcanumZHighResBorders.dat
fi
# The patch's exe changes and its ddraw.dll are the original's; CE implements
# the patch's settings itself and reads HighRes/config.ini.
say "  ${WIDTH}x$(setting Height), borders ${BORDERS:-0}, menu art ${MENU_ART:-0} (HighRes/config.ini)"

# --- 4. Arcanum CE --------------------------------------------------------------

say "4/5 installing Arcanum CE..."
MANIFEST="$DEST/.arcanum-ce-install"
: > "$MANIFEST"
own() { printf '%s\n' "$1" >> "$MANIFEST"; }
if [ "$MACOS" -eq 1 ]; then
    # The app goes beside the game files: its Info.plist makes the folder that
    # holds it the game folder. ditto keeps the bundle's signature, modes and
    # links. The quarantine flag is cleared, as the README says: an app still
    # flagged is run from a hidden read-only copy (App Translocation), where
    # it finds no game.
    say "  unpacking the app..."
    # Into the work folder first, so the app found is the one in our zip, not
    # one a copied game folder brought with it.
    mkdir "$WORK/app"
    ditto -x -k "$HERE/$PAYLOAD" "$WORK/app" || die "could not unpack $PAYLOAD"
    set -- "$WORK/app"/*.app
    [ "$#" -eq 1 ] && [ -d "$1" ] || die "$PAYLOAD must hold exactly one app"
    [ ! -e "$DEST/${1##*/}" ] || die "$DEST already holds ${1##*/}"
    mv "$1" "$DEST/"
    APP="$DEST/${1##*/}"
    own "${APP##*/}"
    xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
    say "  ${APP##*/}"
    if [ -f "$HERE/Uninstall Arcanum CE.command" ]; then
        install -m 0755 "$HERE/Uninstall Arcanum CE.command" "$DEST/Uninstall Arcanum CE.command"
        own "Uninstall Arcanum CE.command"
    fi
    CE_BIN="$APP/Contents/MacOS/$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP/Contents/Info.plist")"
    [ -f "$CE_BIN" ] && [ -x "$CE_BIN" ] || die "the app has no executable at $CE_BIN"
else
    install -m 0755 "$HERE/arcanum-ce" "$DEST/arcanum-ce"; own arcanum-ce
    CE_BIN="$DEST/arcanum-ce"
fi
install -m 0755 "$HERE/uninstall.sh" "$DEST/arcanum-ce-uninstall.sh"; own arcanum-ce-uninstall.sh
KEEP=1
for doc in README.md LICENSE.md THIRD-PARTY-NOTICES.md CHANGES.md; do
    if [ -f "$HERE/$doc" ]; then
        install -m 0644 "$HERE/$doc" "$DEST/arcanum-ce-$doc"; own "arcanum-ce-$doc"
    fi
done
if [ -d "$HERE/ce-mods" ]; then
    cp -a "$HERE/ce-mods" "$DEST/ce-mods"; own ce-mods
fi
# CE's own settings: the original's arcanum.cfg (if the game came with one)
# with the release's lines laid over it. The original's file is never touched.
cfg="$DEST/arcanum-ce.cfg"
if [ -f "$DEST/arcanum.cfg" ]; then cp "$DEST/arcanum.cfg" "$cfg"; else : > "$cfg"; fi
while IFS= read -r line; do
    case "$line" in ''|\#*) continue ;; esac
    key="${line%%=*}"
    if grep -q "^${key}=" "$cfg"; then
        tmp="$cfg.tmp"
        awk -v k="$key" -v l="$line" 'index($0, k "=") == 1 { print l; next } { print }' "$cfg" > "$tmp"
        mv "$tmp" "$cfg"
    else
        printf '%s\n' "$line" >> "$cfg"
    fi
done < "$HERE/arcanum-ce.base.cfg"
for id in $ON_MODS; do
    tmp="$cfg.tmp"
    awk -v k="mod $id=" -v l="mod $id=1" 'index($0, k) == 1 { print l; next } { print }' "$cfg" > "$tmp"
    mv "$tmp" "$cfg"
done
own arcanum-ce.cfg

# --- 5. check, and a menu entry ---------------------------------------------------

say "5/5 checking the installation..."
run_check() {  # the app's own check of the folder; its verdict in $check
    set +e
    ( cd "$DEST" && "$CE_BIN" -check-install ) > "$WORK/check.log" 2>&1
    check=$?
    set -e
}
run_check
if [ "$check" -eq 1 ]; then
    # Loose prototypes from an earlier install hide UAP's fixes. The fix moves
    # them aside, then exits 1 all the same, so a second check judges it.
    say "  moving aside loose prototype files that would hide UAP's fixes..."
    ( cd "$DEST" && "$CE_BIN" -check-install-fix ) > "$WORK/fix.log" 2>&1 || true
    tail -1 "$WORK/fix.log" | sed 's/^/  /'
    run_check
fi
APP_REFUSED=0
if [ "$check" -eq 0 ]; then
    say "  every file the game needs is in place"
elif [ "$MACOS" -eq 1 ] && [ "$check" -gt 2 ]; then
    # Not the check's own verdicts (0, 1, 2): the app did not run, which on a
    # Mac means Gatekeeper. Everything is installed; the app needs one click.
    APP_REFUSED=1
    say "  Arcanum CE is installed, but macOS did not let the app run yet (exit $check)."
else
    sed 's/^/  /' "$WORK/check.log"
    die "the installation check found a problem (exit $check); its report is above"
fi

if [ "$DESKTOP" -eq 1 ]; then
    apps="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
    mkdir -p "$apps"
    icon="$(resolve goggame-1207658829.ico)"
    {
        echo "[Desktop Entry]"
        echo "Type=Application"
        echo "Name=Arcanum CE"
        echo "Comment=Arcanum: Of Steamworks and Magick Obscura - Community Edition"
        echo "Exec=\"$DEST/arcanum-ce\""
        echo "Path=$DEST"
        [ -f "$icon" ] && echo "Icon=$icon"
        echo "Terminal=false"
        echo "Categories=Game;RolePlaying;"
    } > "$apps/arcanum-ce.desktop"
    own "desktop:$apps/arcanum-ce.desktop"
    say "  menu entry: $apps/arcanum-ce.desktop"
fi

DONE=1
say ""
if [ "$APP_REFUSED" -eq 1 ]; then
    say "Open ${APP##*/} from Finder (in $DEST). If macOS says it cannot be opened:"
    say "  on macOS 14 and earlier, right-click it, choose Open, then Open;"
    say "  on macOS 15 and later, choose Open Anyway in System Settings > Privacy & Security,"
    say "  then open it again."
fi
if [ "$UI" = installer ]; then
    say "Done."
    exit 0
fi
if [ "$MACOS" -eq 1 ]; then
    say "Done. Start the game by opening ${APP##*/} in $DEST, or:"
    say "  open \"$APP\""
else
    if [ "$DESKTOP" -eq 1 ]; then say "Done. Start the game from the menu, or:"; else say "Done. Start the game with:"; fi
    say "  cd \"$DEST\" && ./arcanum-ce"
fi
say "Saves go to $DEST/modules/Arcanum/SaveCE. Settings: $DEST/arcanum-ce.cfg."
if [ -n "$ON_MODS" ]; then say "Optional mods on:$ON_MODS"; else say "Optional mods: all off (each is a line in arcanum-ce.cfg)."; fi
say "To remove Arcanum CE: \"$DEST/arcanum-ce-uninstall.sh\""
